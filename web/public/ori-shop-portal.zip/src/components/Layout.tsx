import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useStore, useCurrentUser } from "@/lib/store";
import { useCashDrawers } from "@/lib/cashDrawer";
import { toast } from "sonner";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Truck,
  ClipboardList,
  AlertTriangle,
  Users,
  BarChart3,
  UserCog,
  Settings as SettingsIcon,
  FileText,
  Wallet,
  History,
  DatabaseBackup,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import Logo from "@/components/Logo";
import { useState } from "react";
import { cn } from "@/lib/utils";
import type { Role } from "@/lib/types";

interface NavItem {
  to: string;
  label: string;
  icon: React.ElementType;
  roles: Role[];
}

const NAV: NavItem[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, roles: ["admin", "storekeeper", "cashier"] },
  { to: "/inventory", label: "Inventory", icon: Package, roles: ["admin", "storekeeper", "cashier"] },
  { to: "/sales", label: "Sales (POS)", icon: ShoppingCart, roles: ["admin", "cashier"] },
  { to: "/quotations", label: "Quotations", icon: FileText, roles: ["admin", "cashier"] },
  { to: "/bills", label: "Bill History", icon: History, roles: ["admin", "cashier"] },
  { to: "/cash-drawer", label: "Cash Drawer", icon: Wallet, roles: ["admin", "cashier"] },
  { to: "/suppliers", label: "Suppliers", icon: Truck, roles: ["admin", "storekeeper"] },
  { to: "/orders", label: "Orders", icon: ClipboardList, roles: ["admin", "storekeeper"] },
  { to: "/damaged", label: "Damaged", icon: AlertTriangle, roles: ["admin", "storekeeper"] },
  { to: "/customers", label: "Credit Customers", icon: Users, roles: ["admin", "cashier"] },
  { to: "/reports", label: "Reports", icon: BarChart3, roles: ["admin"] },
  { to: "/users", label: "Users", icon: UserCog, roles: ["admin"] },
  { to: "/settings", label: "Settings", icon: SettingsIcon, roles: ["admin"] },
  { to: "/backup", label: "Backup", icon: DatabaseBackup, roles: ["admin"] },
];

export default function Layout() {
  const user = useCurrentUser();
  const logout = useStore((s) => s.logout);
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const drawers = useCashDrawers((s) => s.drawers);

  if (!user) return null;
  const items = NAV.filter((n) => n.roles.includes(user.role));

  const handleLogout = async (): Promise<void> => {
    // Cashier must close their open drawer (daily closing) before signing out.
    if (user.role === "cashier") {
      const openDrawer = drawers.find(
        (d) => d.cashierId === user.id && d.status === "open"
      );
      if (openDrawer) {
        toast.error(
          "You must close the day before logout. Count cash, confirm expected vs actual, then close drawer.",
          { duration: 5000 }
        );
        setOpen(false);
        navigate("/cash-drawer");
        return;
      }
    }
    await logout();
    navigate("/login");
  };

  return (
    <div className="flex h-screen overflow-hidden pos-surface">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 transform bg-sidebar text-sidebar-foreground transition-transform duration-200 lg:relative lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-16 items-center justify-between border-b border-sidebar-border px-5">
          <div className="flex items-center gap-3">
            <Logo size={36} ring />
            <div>
              <div className="text-sm font-bold tracking-tight text-white">Ori Barakah</div>
              <div className="text-[10px] uppercase tracking-widest text-sidebar-accent-foreground/80">
                Store · Ori Brothers
              </div>
            </div>
          </div>
          <button
            onClick={() => setOpen(false)}
            className="rounded-md p-1 hover:bg-sidebar-accent lg:hidden"
            aria-label="Close menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex flex-col gap-0.5 p-3">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                cn(
                  "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition",
                  isActive
                    ? "bg-sidebar-primary text-sidebar-primary-foreground font-semibold shadow-sm"
                    : "text-sidebar-foreground/85 hover:bg-sidebar-accent hover:text-white"
                )
              }
            >
              <item.icon className="h-4 w-4" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 border-t border-sidebar-border p-3">
          <div className="mb-2 flex items-center gap-3 rounded-lg bg-sidebar-accent/40 px-3 py-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-primary text-sidebar-primary-foreground text-sm font-bold">
              {user.fullName.charAt(0)}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-medium text-white">{user.fullName}</div>
              <div className="text-[11px] uppercase tracking-wider text-sidebar-accent-foreground/70">
                {user.role}
              </div>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-sidebar-border px-3 py-2 text-sm text-sidebar-foreground/90 hover:bg-sidebar-accent hover:text-white"
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </button>
        </div>
      </aside>

      {open && (
        <div
          className="fixed inset-0 z-30 bg-black/50 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-16 items-center gap-3 border-b border-border bg-card/50 px-4 backdrop-blur lg:px-8">
          <button
            onClick={() => setOpen(true)}
            className="rounded-md p-1.5 hover:bg-secondary lg:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-3">
            <Logo size={36} className="hidden sm:block ring-1 ring-border" />
            <div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground">
                Welcome back
              </div>
              <div className="text-sm font-semibold">{user.fullName}</div>
            </div>
          </div>
          <div className="flex-1" />
          <div className="hidden items-center gap-2 rounded-full bg-secondary px-3 py-1.5 text-xs font-medium text-secondary-foreground sm:flex">
            <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
            Live · {new Date().toLocaleDateString()}
          </div>
          <div className="ml-2 hidden rounded-full border border-border bg-card px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground sm:block">
            {user.role} POS
          </div>
        </header>
        <main className="flex-1 overflow-y-auto scrollbar-thin brand-watermark">
          <div className="relative z-10 mx-auto max-w-[1400px] p-4 lg:p-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
