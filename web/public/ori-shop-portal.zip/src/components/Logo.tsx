import { cn } from "@/lib/utils";

export const LOGO_URL =
  "https://pub-e001eb4506b145aa938b5d3badbff6a5.r2.dev/attachments/33rbc3xbwihdsvk0yelbx.jpeg";

interface LogoProps {
  size?: number;
  className?: string;
  ring?: boolean;
}

export default function Logo({ size = 40, className, ring = false }: LogoProps) {
  return (
    <img
      src={LOGO_URL}
      alt="Ori Barakah Store"
      width={size}
      height={size}
      className={cn(
        "rounded-full object-cover bg-white",
        ring && "ring-2 ring-white/80 shadow-md",
        className
      )}
      style={{ width: size, height: size }}
    />
  );
}
