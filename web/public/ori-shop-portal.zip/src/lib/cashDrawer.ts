import { create } from "zustand";
import { persist } from "zustand/middleware";

export type DrawerStatus = "open" | "closed";

export interface DenominationCount {
  /** denomination value (e.g. 1000) */
  value: number;
  /** how many notes/coins counted */
  count: number;
}

export interface CashDrawer {
  id: string;
  cashierId: string;
  cashierName: string;
  openedAt: string; // ISO
  closedAt?: string; // ISO
  status: DrawerStatus;
  openingCash: number;
  // recorded sale aggregates at close (snapshot)
  cashSales?: number;
  cardSales?: number;
  bankSales?: number;
  creditSales?: number;
  totalSales?: number;
  changeGiven?: number;
  gstCollected?: number;
  bagFeesCollected?: number;
  cardFeesCollected?: number;
  discountsGiven?: number;
  expectedCash?: number;
  countedCash?: number;
  difference?: number;
  denominations?: DenominationCount[];
  notes?: string;
  approvedByAdmin?: boolean;
}

interface CashDrawerState {
  drawers: CashDrawer[];
  open: (
    cashierId: string,
    cashierName: string,
    openingCash: number
  ) => CashDrawer;
  close: (id: string, patch: Partial<CashDrawer>) => void;
  approve: (id: string) => void;
  remove: (id: string) => void;
  /** Currently open drawer for a given cashier */
  currentForCashier: (cashierId: string) => CashDrawer | undefined;
}

export const DEFAULT_DENOMINATIONS: DenominationCount[] = [
  { value: 1000, count: 0 },
  { value: 500, count: 0 },
  { value: 100, count: 0 },
  { value: 50, count: 0 },
  { value: 20, count: 0 },
  { value: 10, count: 0 },
  { value: 5, count: 0 },
  { value: 2, count: 0 },
  { value: 1, count: 0 },
];

export const sumDenominations = (d: DenominationCount[]): number =>
  d.reduce((s, x) => s + x.value * Math.max(0, x.count), 0);

export const useCashDrawers = create<CashDrawerState>()(
  persist(
    (set, get) => ({
      drawers: [],
      open: (cashierId, cashierName, openingCash) => {
        const id = `cd_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
        const drawer: CashDrawer = {
          id,
          cashierId,
          cashierName,
          openedAt: new Date().toISOString(),
          status: "open",
          openingCash,
        };
        set({ drawers: [drawer, ...get().drawers] });
        return drawer;
      },
      close: (id, patch) =>
        set({
          drawers: get().drawers.map((d) =>
            d.id === id
              ? {
                  ...d,
                  ...patch,
                  status: "closed",
                  closedAt: patch.closedAt ?? new Date().toISOString(),
                }
              : d
          ),
        }),
      approve: (id) =>
        set({
          drawers: get().drawers.map((d) =>
            d.id === id ? { ...d, approvedByAdmin: true } : d
          ),
        }),
      remove: (id) =>
        set({ drawers: get().drawers.filter((d) => d.id !== id) }),
      currentForCashier: (cashierId) =>
        get().drawers.find(
          (d) => d.cashierId === cashierId && d.status === "open"
        ),
    }),
    { name: "ori-cash-drawers" }
  )
);
