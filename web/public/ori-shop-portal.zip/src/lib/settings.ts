import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface PosSettings {
  gstEnabled: boolean;
  gstPercent: number;
  plasticBagFee: number;
  cardChargePercent: number;
  /** If true, plastic bag fee is added to the GST taxable base. */
  bagFeeTaxable: boolean;
  shopName: string;
  receiptFooter: string;
  // Company / contact details (used on quotation & invoices)
  companyAddress: string;
  companyPhone: string;
  companyEmail: string;
  companyRegNo: string;
  // Bank details for quotation payment block
  bankName: string;
  bankAccountName: string;
  bankAccountNumber: string;
  bankBeneficiary: string;
  // Quotation terms & validity
  quotationValidityDays: number;
  quotationTerms: string;
  set: (patch: Partial<Omit<PosSettings, "set">>) => void;
}

export const useSettings = create<PosSettings>()(
  persist(
    (set) => ({
      gstEnabled: true,
      gstPercent: 8,
      plasticBagFee: 0,
      cardChargePercent: 0,
      bagFeeTaxable: false,
      shopName: "Ori Barakah Store",
      receiptFooter: "Thank you for shopping with us!",
      companyAddress: "Lucky House, Asrafee Goalhi, R.Ungoofaaru",
      companyPhone: "9220222",
      companyEmail: "sales@oribrothers.com",
      companyRegNo: "",
      bankName: "Bank of Maldives",
      bankAccountName: "ORI BARAKAH STORE",
      bankAccountNumber: "7770000190257",
      bankBeneficiary: "Ibrahim Ayaan",
      quotationValidityDays: 7,
      quotationTerms:
        "1. Quotation is valid for the period stated above.\n2. Prices may change after the validity period.\n3. Order is confirmed only upon receipt of PO or written approval.\n4. Delivery as per agreed schedule. Payment as per agreed terms. GST applicable.\n5. For more information please contact 9220222.",
      set: (patch) => set(patch),
    }),
    { name: "ori-pos-settings", version: 2 }
  )
);
