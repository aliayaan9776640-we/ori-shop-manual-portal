export type Role = "admin" | "storekeeper" | "cashier";

export interface User {
  id: string;
  /** Email — used as the login identifier (was "username" before Supabase). */
  username: string;
  email: string;
  /** Only present in legacy local-only mode. Never read from Supabase. */
  password?: string;
  fullName: string;
  role: Role;
  active: boolean;
  createdAt: string;
}

export type UnitType = "piece" | "kg" | "tin" | "box" | "case";

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  viber: string;
  email: string;
  address: string;
  notes: string;
}

export interface Product {
  id: string;
  name: string;
  barcode: string;
  category: string;
  supplierId: string;
  purchasePrice: number;
  sellingPrice: number;
  marginPct: number; // editable
  unit: UnitType;
  piecesPerCase: number;
  stockPieces: number;
  reorderLevel: number; // pieces
  expiryDate?: string;
  boatFee: number;
  otherCost: number;
  photo?: string;
  /** Whether GST should be charged on this product when sold. Defaults to true if undefined. */
  gstApplicable?: boolean;
}

export interface SaleItem {
  productId: string;
  name: string;
  qty: number; // in pieces
  unit: UnitType;
  unitQty: number; // qty in displayed unit
  price: number; // selling price per piece
  landedCost: number; // per piece
  total: number;
  profit: number;
  gstApplicable?: boolean;
}

export type PaymentMethod = "cash" | "card" | "bank" | "credit";

export interface Sale {
  id: string;
  date: string; // ISO
  items: SaleItem[];
  total: number;
  profit: number;
  paymentMethod: PaymentMethod;
  customerId?: string;
  cashierId: string;
  /** Admin-only protection fields */
  voided?: boolean;
  voidedAt?: string;
  voidedBy?: string;
  voidedByName?: string;
  voidReason?: string;
  editedAt?: string;
  editedBy?: string;
  editedByName?: string;
}

export interface DamagedItem {
  id: string;
  productId: string;
  name: string;
  qty: number; // pieces
  unit: UnitType;
  unitQty: number;
  reason: string;
  date: string;
  valueLoss: number;
  reportedBy: string;
  reportedByName?: string;
  landedCostPerPiece?: number;
  stockBefore?: number;
  stockAfter?: number;
  notes?: string;
  barcode?: string;
}

export type OrderStatus = "pending" | "loaded" | "received" | "partial" | "cancelled";

export interface OrderItem {
  productId: string;
  name: string;
  currentStock: number;
  qty: number; // pieces
  unit: UnitType;
  unitQty: number;
  receivedQty: number; // pieces
  notes?: string;
}

export interface Order {
  id: string;
  supplierId: string;
  date: string;
  items: OrderItem[];
  status: OrderStatus;
  boatName?: string;
  boatContact?: string;
  loadingDate?: string;
  sentDate?: string;
  expectedDate?: string;
  receivedDate?: string;
  notes?: string;
}

export type CreditApprovalStatus = "pending" | "approved" | "rejected";

export interface CreditCustomer {
  id: string;
  name: string;
  phone: string;
  address: string;
  openingBalance: number;
  /** Final approved credit limit. 0 until admin approves. */
  creditLimit: number;
  /** Limit requested by cashier when creating the customer. */
  requestedCreditLimit?: number;
  notes: string;
  balance: number; // current outstanding
  approvalStatus: CreditApprovalStatus;
  approvedBy?: string;
  approvedByName?: string;
  approvedAt?: string;
}

export interface CreditTransaction {
  id: string;
  customerId: string;
  date: string;
  type: "sale" | "payment";
  amount: number;
  saleId?: string;
  note?: string;
}

export interface ActivityLog {
  id: string;
  date: string;
  userId: string;
  userName: string;
  action: string;
  detail: string;
}
