import { create } from "zustand";
import type {
  ActivityLog,
  CreditApprovalStatus,
  CreditCustomer,
  CreditTransaction,
  DamagedItem,
  Order,
  OrderItem,
  PaymentMethod,
  Product,
  Sale,
  SaleItem,
  Supplier,
  User,
} from "./types";
import {
  buildSeedSales,
  seedCreditTx,
  seedCustomers,
  seedDamaged,
  seedOrders,
  seedProducts,
  seedSuppliers,
  seedUsers,
} from "./seed";
import { supabase, isSupabaseConfigured } from "./supabase";
import type { PostgrestError } from "@supabase/supabase-js";

/* ----------------------------- helpers ------------------------------ */

export const landedCostPerPiece = (p: Product): number => {
  const total = p.purchasePrice + p.boatFee + p.otherCost;
  return total / Math.max(1, p.piecesPerCase || 1);
};

export const landedCostTotal = (p: Product): number =>
  p.purchasePrice + p.boatFee + p.otherCost;

export const suggestedSellingPrice = (p: Product): number => {
  const landed = landedCostTotal(p);
  return landed * (1 + p.marginPct / 100);
};

const localId = (prefix: string): string =>
  `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;

const logErr = (where: string, err: PostgrestError | Error | null): void => {
  if (!err) return;
  // eslint-disable-next-line no-console
  console.error(`[supabase][${where}]`, err.message ?? err);
};

/* ------------------------- row <-> type mappers --------------------- */

interface ProfileRow {
  id: string;
  email: string;
  full_name: string | null;
  role: "admin" | "storekeeper" | "cashier";
  active: boolean;
  created_at: string;
}
const rowToUser = (r: ProfileRow): User => ({
  id: r.id,
  username: r.email,
  email: r.email,
  fullName: r.full_name ?? r.email,
  role: r.role,
  active: r.active,
  createdAt: r.created_at,
});

interface SupplierRow {
  id: string;
  name: string;
  contact_person: string | null;
  phone: string | null;
  viber: string | null;
  email: string | null;
  address: string | null;
  notes: string | null;
}
const rowToSupplier = (r: SupplierRow): Supplier => ({
  id: r.id,
  name: r.name,
  contactPerson: r.contact_person ?? "",
  phone: r.phone ?? "",
  viber: r.viber ?? "",
  email: r.email ?? "",
  address: r.address ?? "",
  notes: r.notes ?? "",
});
const supplierToRow = (s: Partial<Supplier>): Partial<SupplierRow> => ({
  name: s.name,
  contact_person: s.contactPerson ?? null,
  phone: s.phone ?? null,
  viber: s.viber ?? null,
  email: s.email ?? null,
  address: s.address ?? null,
  notes: s.notes ?? null,
});

interface ProductRow {
  id: string;
  name: string;
  barcode: string | null;
  category: string | null;
  supplier_id: string | null;
  purchase_price: number;
  selling_price: number;
  margin_pct: number;
  unit_type: Product["unit"];
  pieces_per_case: number;
  stock_pieces: number;
  reorder_level: number;
  expiry_date: string | null;
  boat_fee: number;
  other_cost: number;
  photo_url: string | null;
  gst_applicable?: boolean | null;
}
const rowToProduct = (r: ProductRow): Product => ({
  id: r.id,
  name: r.name,
  barcode: r.barcode ?? "",
  category: r.category ?? "",
  supplierId: r.supplier_id ?? "",
  purchasePrice: Number(r.purchase_price),
  sellingPrice: Number(r.selling_price),
  marginPct: Number(r.margin_pct),
  unit: r.unit_type,
  piecesPerCase: r.pieces_per_case,
  stockPieces: r.stock_pieces,
  reorderLevel: r.reorder_level,
  expiryDate: r.expiry_date ?? undefined,
  boatFee: Number(r.boat_fee),
  otherCost: Number(r.other_cost),
  photo: r.photo_url ?? undefined,
  gstApplicable: r.gst_applicable === false ? false : true,
});
const productToRow = (p: Partial<Product>): Partial<ProductRow> => ({
  name: p.name,
  barcode: p.barcode || null,
  category: p.category || null,
  supplier_id: p.supplierId || null,
  purchase_price: p.purchasePrice,
  selling_price: p.sellingPrice,
  margin_pct: p.marginPct,
  unit_type: p.unit,
  pieces_per_case: p.piecesPerCase,
  stock_pieces: p.stockPieces,
  reorder_level: p.reorderLevel,
  expiry_date: p.expiryDate || null,
  boat_fee: p.boatFee,
  other_cost: p.otherCost,
  photo_url: p.photo || null,
  ...(p.gstApplicable !== undefined ? { gst_applicable: p.gstApplicable } : {}),
});

interface CustomerRow {
  id: string;
  name: string;
  phone: string | null;
  address: string | null;
  opening_balance: number;
  credit_limit: number;
  balance: number;
  notes: string | null;
  requested_credit_limit?: number | null;
  approval_status?: "pending" | "approved" | "rejected" | null;
  approved_by?: string | null;
  approved_at?: string | null;
}
const rowToCustomer = (r: CustomerRow): CreditCustomer => ({
  id: r.id,
  name: r.name,
  phone: r.phone ?? "",
  address: r.address ?? "",
  openingBalance: Number(r.opening_balance),
  creditLimit: Number(r.credit_limit),
  requestedCreditLimit: r.requested_credit_limit != null ? Number(r.requested_credit_limit) : undefined,
  balance: Number(r.balance),
  notes: r.notes ?? "",
  approvalStatus: r.approval_status ?? "approved",
  approvedBy: r.approved_by ?? undefined,
  approvedAt: r.approved_at ?? undefined,
});

/* ------------------------------- store ------------------------------ */

interface AppState {
  // auth / hydration
  currentUserId: string | null;
  hydrated: boolean;
  bootstrapping: boolean;

  // data
  users: User[];
  products: Product[];
  suppliers: Supplier[];
  sales: Sale[];
  damaged: DamagedItem[];
  orders: Order[];
  customers: CreditCustomer[];
  creditTx: CreditTransaction[];
  logs: ActivityLog[];

  // hydration
  bootstrap: () => Promise<void>;

  // auth actions (async with Supabase)
  login: (
    email: string,
    password: string
  ) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;

  // user mgmt
  addUser: (
    u: Omit<User, "id" | "createdAt"> & { password: string }
  ) => Promise<{ ok: boolean; error?: string }>;
  updateUser: (id: string, patch: Partial<User>) => void;
  deleteUser: (id: string) => void;

  // products
  addProduct: (p: Omit<Product, "id">) => void;
  updateProduct: (id: string, patch: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  adjustStock: (productId: string, deltaPieces: number, reason: string) => void;

  // suppliers
  addSupplier: (s: Omit<Supplier, "id">) => void;
  updateSupplier: (id: string, patch: Partial<Supplier>) => void;
  deleteSupplier: (id: string) => void;

  // sales
  addSale: (
    items: SaleItem[],
    paymentMethod: Sale["paymentMethod"],
    customerId?: string
  ) => Sale;
  /** Admin-only. Voids a sale, restores stock, reverses credit, logs the action. */
  voidSale: (id: string, reason: string) => { ok: boolean; error?: string };
  /** Admin-only. Edits a sale's payment method or customer. Logs before/after. */
  editSale: (
    id: string,
    patch: { paymentMethod?: PaymentMethod; customerId?: string },
    reason: string
  ) => { ok: boolean; error?: string };

  // damaged
  addDamaged: (d: Omit<DamagedItem, "id" | "reportedBy" | "date">) => void;

  // orders
  addOrder: (supplierId: string, items: OrderItem[], notes?: string) => Order;
  updateOrder: (id: string, patch: Partial<Order>) => void;
  receiveOrderItem: (
    orderId: string,
    productId: string,
    receivedQtyPieces: number
  ) => void;
  markOrderReceived: (orderId: string) => void;

  // customers
  addCustomer: (
    c: Omit<CreditCustomer, "id" | "balance" | "approvalStatus"> & {
      approvalStatus?: CreditCustomer["approvalStatus"];
    }
  ) => void;
  updateCustomer: (id: string, patch: Partial<CreditCustomer>) => void;
  deleteCustomer: (id: string) => void;
  addCreditPayment: (customerId: string, amount: number, note?: string) => void;
  approveCustomer: (id: string, finalLimit: number) => void;
  rejectCustomer: (id: string) => void;

  // logging
  log: (action: string, detail: string) => void;

  // reset (local only)
  resetData: () => void;
}

const seedSalesData = buildSeedSales(seedProducts);

const initial = {
  currentUserId: null as string | null,
  hydrated: false,
  bootstrapping: false,
  users: [] as User[],
  products: seedProducts,
  suppliers: seedSuppliers,
  sales: seedSalesData,
  damaged: seedDamaged,
  orders: seedOrders,
  customers: seedCustomers,
  creditTx: seedCreditTx,
  logs: [] as ActivityLog[],
};

export const useStore = create<AppState>()((set, get) => ({
  ...initial,

  /* ------------------------- bootstrap ----------------------------- */
  bootstrap: async () => {
    if (!isSupabaseConfigured) {
      set({ hydrated: true });
      return;
    }
    if (get().bootstrapping) return;
    set({ bootstrapping: true });
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const uid = sessionData.session?.user.id ?? null;

      // Load profiles (needed for both auth + Users page)
      const { data: profiles, error: pErr } = await supabase
        .from("profiles")
        .select("*")
        .order("created_at", { ascending: true });
      logErr("profiles.select", pErr);
      const users: User[] = (profiles as ProfileRow[] | null)?.map(rowToUser) ?? [];

      // If the current session belongs to a deactivated user, sign them out
      // immediately so a previously-active token can no longer reach the app.
      if (uid) {
        const me = users.find((u) => u.id === uid);
        if (me && !me.active) {
          console.warn("[bootstrap] signing out inactive user", me.email);
          try {
            await supabase.auth.signOut();
          } catch (e) {
            console.warn("[bootstrap] signOut warning", e);
          }
          set({
            users,
            currentUserId: null,
            hydrated: true,
            bootstrapping: false,
          });
          return;
        }
      }

      // If we have a session but no profile row exists yet, create one.
      let resolvedUid = uid;
      if (uid && !users.find((u) => u.id === uid)) {
        const email = sessionData.session?.user.email ?? "";
        const { data: newProfile, error: insErr } = await supabase
          .from("profiles")
          .insert({
            id: uid,
            email,
            full_name: email,
            role: "cashier",
            active: true,
          })
          .select()
          .single();
        logErr("profiles.upsert-self", insErr);
        if (newProfile) {
          users.push(rowToUser(newProfile as ProfileRow));
        }
        resolvedUid = uid;
      }

      const [
        suppliersRes,
        productsRes,
        customersRes,
        salesRes,
        saleItemsRes,
        ordersRes,
        orderItemsRes,
        damagedRes,
        creditTxRes,
        logsRes,
      ] = await Promise.all([
        supabase.from("suppliers").select("*").order("name"),
        supabase.from("products").select("*").order("name"),
        supabase.from("customers").select("*").order("name"),
        supabase
          .from("sales")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(500),
        supabase.from("sale_items").select("*"),
        supabase.from("orders").select("*").order("created_at", { ascending: false }),
        supabase.from("order_items").select("*"),
        supabase
          .from("damaged_items")
          .select("*")
          .order("created_at", { ascending: false }),
        supabase
          .from("credit_transactions")
          .select("*")
          .order("created_at", { ascending: false }),
        supabase
          .from("activity_logs")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(200),
      ]);

      const suppliers: Supplier[] =
        (suppliersRes.data as SupplierRow[] | null)?.map(rowToSupplier) ?? [];
      const products: Product[] =
        (productsRes.data as ProductRow[] | null)?.map(rowToProduct) ?? [];
      const customers: CreditCustomer[] =
        (customersRes.data as CustomerRow[] | null)?.map(rowToCustomer) ?? [];

      // sales + sale_items
      interface SaleRow {
        id: string;
        invoice_no: string | null;
        customer_id: string | null;
        payment_method: Sale["paymentMethod"];
        total: number;
        profit: number;
        user_id: string | null;
        created_at: string;
        voided?: boolean | null;
        voided_at?: string | null;
        voided_by?: string | null;
        void_reason?: string | null;
        edited_at?: string | null;
        edited_by?: string | null;
      }
      interface SaleItemRow {
        id: string;
        sale_id: string;
        product_id: string;
        qty: number;
        unit_type: SaleItem["unit"];
        unit_price: number;
        landed_cost: number;
        line_total: number;
        line_profit: number;
      }
      const saleItemsByOrder: Record<string, SaleItemRow[]> = {};
      ((saleItemsRes.data as SaleItemRow[] | null) ?? []).forEach((si) => {
        if (!saleItemsByOrder[si.sale_id]) saleItemsByOrder[si.sale_id] = [];
        saleItemsByOrder[si.sale_id].push(si);
      });
      const sales: Sale[] = ((salesRes.data as SaleRow[] | null) ?? []).map((s) => {
        const items: SaleItem[] = (saleItemsByOrder[s.id] ?? []).map((si) => {
          const product = products.find((p) => p.id === si.product_id);
          return {
            productId: si.product_id,
            name: product?.name ?? "(deleted)",
            qty: si.qty,
            unit: si.unit_type,
            unitQty: si.qty,
            price: Number(si.unit_price),
            landedCost: Number(si.landed_cost),
            total: Number(si.line_total),
            profit: Number(si.line_profit),
          };
        });
        const voidedByUser = s.voided_by
          ? users.find((u) => u.id === s.voided_by)
          : undefined;
        const editedByUser = s.edited_by
          ? users.find((u) => u.id === s.edited_by)
          : undefined;
        return {
          id: s.id,
          date: s.created_at,
          items,
          total: Number(s.total),
          profit: Number(s.profit),
          paymentMethod: s.payment_method,
          customerId: s.customer_id ?? undefined,
          cashierId: s.user_id ?? "",
          voided: s.voided ?? undefined,
          voidedAt: s.voided_at ?? undefined,
          voidedBy: s.voided_by ?? undefined,
          voidedByName: voidedByUser?.fullName,
          voidReason: s.void_reason ?? undefined,
          editedAt: s.edited_at ?? undefined,
          editedBy: s.edited_by ?? undefined,
          editedByName: editedByUser?.fullName,
        };
      });

      // orders + order_items
      interface OrderRow {
        id: string;
        supplier_id: string;
        status: Order["status"];
        boat_name: string | null;
        boat_contact: string | null;
        loading_date: string | null;
        sent_date: string | null;
        expected_date: string | null;
        received_date: string | null;
        notes: string | null;
        created_at: string;
      }
      interface OrderItemRow {
        id: string;
        order_id: string;
        product_id: string;
        qty: number;
        unit_type: OrderItem["unit"];
        received_qty: number;
        notes: string | null;
      }
      const orderItemsByOrder: Record<string, OrderItemRow[]> = {};
      ((orderItemsRes.data as OrderItemRow[] | null) ?? []).forEach((oi) => {
        if (!orderItemsByOrder[oi.order_id]) orderItemsByOrder[oi.order_id] = [];
        orderItemsByOrder[oi.order_id].push(oi);
      });
      const orders: Order[] = ((ordersRes.data as OrderRow[] | null) ?? []).map((o) => {
        const items: OrderItem[] = (orderItemsByOrder[o.id] ?? []).map((oi) => {
          const p = products.find((x) => x.id === oi.product_id);
          return {
            productId: oi.product_id,
            name: p?.name ?? "(deleted)",
            currentStock: p?.stockPieces ?? 0,
            qty: oi.qty,
            unit: oi.unit_type,
            unitQty: oi.qty,
            receivedQty: oi.received_qty,
            notes: oi.notes ?? undefined,
          };
        });
        return {
          id: o.id,
          supplierId: o.supplier_id,
          date: o.created_at,
          items,
          status: o.status,
          boatName: o.boat_name ?? undefined,
          boatContact: o.boat_contact ?? undefined,
          loadingDate: o.loading_date ?? undefined,
          sentDate: o.sent_date ?? undefined,
          expectedDate: o.expected_date ?? undefined,
          receivedDate: o.received_date ?? undefined,
          notes: o.notes ?? undefined,
        };
      });

      // damaged
      interface DamageRow {
        id: string;
        product_id: string;
        qty: number;
        unit_type: DamagedItem["unit"];
        reason: string | null;
        landed_cost_per_unit: number;
        loss_amount: number;
        stock_before: number | null;
        stock_after: number | null;
        user_id: string | null;
        date: string;
        notes: string | null;
        created_at: string;
      }
      const damaged: DamagedItem[] = ((damagedRes.data as DamageRow[] | null) ?? []).map(
        (d) => {
          const p = products.find((x) => x.id === d.product_id);
          const u = users.find((x) => x.id === d.user_id);
          return {
            id: d.id,
            productId: d.product_id,
            name: p?.name ?? "(deleted)",
            qty: d.qty,
            unit: d.unit_type,
            unitQty: d.qty,
            reason: d.reason ?? "",
            date: d.created_at,
            valueLoss: Number(d.loss_amount),
            reportedBy: d.user_id ?? "",
            reportedByName: u?.fullName,
            landedCostPerPiece: Number(d.landed_cost_per_unit),
            stockBefore: d.stock_before ?? undefined,
            stockAfter: d.stock_after ?? undefined,
            notes: d.notes ?? undefined,
            barcode: p?.barcode,
          };
        }
      );

      interface CreditTxRow {
        id: string;
        customer_id: string;
        type: CreditTransaction["type"];
        amount: number;
        sale_id: string | null;
        note: string | null;
        created_at: string;
      }
      const creditTx: CreditTransaction[] = (
        (creditTxRes.data as CreditTxRow[] | null) ?? []
      ).map((c) => ({
        id: c.id,
        customerId: c.customer_id,
        date: c.created_at,
        type: c.type === "payment" ? "payment" : "sale",
        amount: Number(c.amount),
        saleId: c.sale_id ?? undefined,
        note: c.note ?? undefined,
      }));

      interface LogRow {
        id: string;
        user_id: string | null;
        action: string;
        entity: string | null;
        meta: { detail?: string } | null;
        created_at: string;
      }
      const logs: ActivityLog[] = ((logsRes.data as LogRow[] | null) ?? []).map((l) => {
        const u = users.find((x) => x.id === l.user_id);
        return {
          id: l.id,
          date: l.created_at,
          userId: l.user_id ?? "system",
          userName: u?.fullName ?? "System",
          action: l.action,
          detail: l.meta?.detail ?? "",
        };
      });

      set({
        users: users.length ? users : get().users,
        suppliers,
        products,
        customers,
        sales,
        damaged,
        orders,
        creditTx,
        logs,
        currentUserId: resolvedUid,
        hydrated: true,
        bootstrapping: false,
      });
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error("[bootstrap]", e);
      set({ bootstrapping: false, hydrated: true });
    }
  },

  /* --------------------------- auth -------------------------------- */
  login: async (email, password) => {
    if (!isSupabaseConfigured) {
      console.error("[login] Supabase is not configured. Local/demo login is disabled.");
      return {
        ok: false,
        error: "Supabase is not configured. Contact your administrator.",
      };
    }
    // 1. Clear any previous session completely before logging in.
    try {
      await supabase.auth.signOut();
    } catch (e) {
      console.warn("[login] pre-signOut warning", e);
    }
    set({
      currentUserId: null,
      hydrated: false,
      bootstrapping: false,
    });

    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error || !data.user) {
      const msg = error?.message ?? "Login failed";
      console.error("[login] signInWithPassword failed", {
        email: email.trim(),
        message: msg,
        status: error?.status,
      });
      const lower = msg.toLowerCase();
      if (lower.includes("not confirmed") || lower.includes("confirm")) {
        return {
          ok: false,
          error:
            "Email not confirmed. Ask your admin to resend the confirmation email, or disable \"Confirm email\" in Supabase Auth settings.",
        };
      }
      if (lower.includes("invalid login")) {
        return {
          ok: false,
          error:
            "Invalid email or password. If you were just created, your email may need confirmation first.",
        };
      }
      return { ok: false, error: msg };
    }

    // 2. Re-fetch the canonical current user from Supabase.
    const { data: userData, error: userErr } = await supabase.auth.getUser();
    if (userErr || !userData.user) {
      await supabase.auth.signOut();
      set({ currentUserId: null });
      return { ok: false, error: userErr?.message ?? "Failed to load session" };
    }
    const authUser = userData.user;

    // 3. Re-fetch the profile by user.id. We MUST be able to read it; if RLS
    // or a missing row blocks us, fail closed instead of allowing access.
    const { data: profileRow, error: profErr } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", authUser.id)
      .maybeSingle();
    if (profErr) {
      console.error("[login] profile fetch error", {
        userId: authUser.id,
        message: profErr.message,
        code: profErr.code,
      });
      await supabase.auth.signOut();
      set({ currentUserId: null });
      return {
        ok: false,
        error: "Could not verify your account. Please try again.",
      };
    }
    const profile = profileRow
      ? rowToUser(profileRow as ProfileRow)
      : null;

    if (!profile) {
      await supabase.auth.signOut();
      set({ currentUserId: null });
      return {
        ok: false,
        error: "No profile found for this account. Contact an admin.",
      };
    }

    if (!profile.active) {
      console.warn("[login] blocked inactive user", profile.email);
      await supabase.auth.signOut();
      set({ currentUserId: null, hydrated: true });
      return { ok: false, error: "Account is deactivated. Contact an admin." };
    }

    // 4. Update app state with the new user BEFORE bootstrapping so any
    // role-gated UI renders correctly.
    set({ currentUserId: authUser.id });

    // 5. Logging.
    console.log("[login] success", {
      email: authUser.email,
      id: authUser.id,
      role: profile?.role ?? "(no profile)",
      fullName: profile?.fullName,
    });

    // 6. Reload all data for the new user.
    await get().bootstrap();

    return { ok: true };
  },

  logout: async () => {
    if (isSupabaseConfigured) {
      try {
        await supabase.auth.signOut();
      } catch (e) {
        console.warn("[logout] signOut warning", e);
      }
    }
    // Wipe per-user state so the next login starts clean.
    set({
      currentUserId: null,
      hydrated: false,
      bootstrapping: false,
      users: [],
      suppliers: [],
      products: [],
      customers: [],
      sales: [],
      damaged: [],
      orders: [],
      creditTx: [],
      logs: [],
    });
    console.log("[logout] session cleared");
  },

  /* ------------------------ user mgmt ------------------------------ */
  addUser: async (u) => {
    if (!isSupabaseConfigured) {
      const newU: User = {
        ...u,
        id: localId("u"),
        createdAt: new Date().toISOString(),
      };
      set({ users: [...get().users, newU] });
      return { ok: true };
    }

    const email = u.email.trim().toLowerCase();

    // Force signUp-only flow: use a secondary Supabase client so the admin's
    // session in the main client is NOT replaced by the new user's session.
    // This works as long as "Confirm email" is disabled in the Supabase
    // Auth settings (Dashboard → Authentication → Providers → Email →
    // "Confirm email" = OFF).
    const { buildAdminSignupClient } = await import("./supabase");
    const tmp = buildAdminSignupClient();

    const { data, error } = await tmp.auth.signUp({
      email,
      password: u.password,
      options: {
        data: { full_name: u.fullName, role: u.role },
        emailRedirectTo: `${window.location.origin}/login`,
      },
    });
    console.log("[addUser] signUp result", {
      userId: data?.user?.id,
      hasSession: !!data?.session,
      identities: data?.user?.identities?.length,
      error: error?.message,
    });

    if (error || !data?.user) {
      return {
        ok: false,
        error:
          error?.message ??
          "Failed to create user. Make sure \"Confirm email\" is disabled in Supabase Auth settings.",
      };
    }

    // Supabase returns an existing user with empty identities[] when the
    // email is already registered (instead of an error). Detect that case.
    if (data.user.identities && data.user.identities.length === 0) {
      return {
        ok: false,
        error: "A user with this email already exists.",
      };
    }

    const newId = data.user.id;
    const needsEmailConfirm = !data.session;
    if (needsEmailConfirm) {
      console.warn(
        "[addUser] Supabase returned no session — \"Confirm email\" is ON. The user must confirm via email before they can log in."
      );
    }

    // The DB trigger `handle_new_user` may auto-insert a profile row with
    // role='cashier'. Upsert with the admin's authenticated session in the
    // main client to apply the requested role / full name / active status.
    const { error: pErr } = await supabase
      .from("profiles")
      .upsert(
        {
          id: newId,
          email,
          full_name: u.fullName,
          role: u.role,
          active: u.active,
        },
        { onConflict: "id" }
      );
    logErr("profiles.upsert", pErr);
    if (pErr) {
      return { ok: false, error: pErr.message };
    }

    const newU: User = {
      id: newId,
      username: email,
      email,
      fullName: u.fullName,
      role: u.role,
      active: u.active,
      createdAt: new Date().toISOString(),
    };
    set({ users: [...get().users, newU] });
    get().log("user.create", `Created user ${email} (${u.role})`);
    return {
      ok: true,
      error: needsEmailConfirm
        ? "created-pending-confirmation"
        : undefined,
    };
  },

  updateUser: (uid, patch) => {
    set({
      users: get().users.map((u) => (u.id === uid ? { ...u, ...patch } : u)),
    });
    if (isSupabaseConfigured) {
      const row: Record<string, unknown> = {};
      if (patch.fullName !== undefined) row.full_name = patch.fullName;
      if (patch.role !== undefined) row.role = patch.role;
      if (patch.active !== undefined) row.active = patch.active;
      if (patch.email !== undefined) row.email = patch.email;
      if (Object.keys(row).length > 0) {
        supabase
          .from("profiles")
          .update(row)
          .eq("id", uid)
          .then(({ error }) => logErr("profiles.update", error));
      }
    }
    get().log("user.update", `Updated user ${uid}`);
  },

  deleteUser: (uid) => {
    set({ users: get().users.filter((u) => u.id !== uid) });
    if (isSupabaseConfigured) {
      // We can only soft-delete the profile from the client;
      // deleting the auth user requires the service-role key.
      supabase
        .from("profiles")
        .update({ active: false })
        .eq("id", uid)
        .then(({ error }) => logErr("profiles.deactivate", error));
    }
    get().log("user.delete", `Deleted user ${uid}`);
  },

  /* ------------------------ products ------------------------------- */
  addProduct: (p) => {
    const tempId = localId("p");
    const newP: Product = { ...p, id: tempId };
    set({ products: [...get().products, newP] });
    get().log("product.create", `Added product ${newP.name}`);
    if (!isSupabaseConfigured) return;
    supabase
      .from("products")
      .insert(productToRow(p))
      .select()
      .single()
      .then(({ data, error }) => {
        logErr("products.insert", error);
        if (data) {
          const real = rowToProduct(data as ProductRow);
          set({
            products: get().products.map((x) => (x.id === tempId ? real : x)),
          });
        }
      });
  },
  updateProduct: (pid, patch) => {
    set({
      products: get().products.map((p) =>
        p.id === pid ? { ...p, ...patch } : p
      ),
    });
    get().log("product.update", `Updated product ${pid}`);
    if (!isSupabaseConfigured) return;
    supabase
      .from("products")
      .update(productToRow(patch))
      .eq("id", pid)
      .then(({ error }) => logErr("products.update", error));
  },
  deleteProduct: (pid) => {
    set({ products: get().products.filter((p) => p.id !== pid) });
    get().log("product.delete", `Deleted product ${pid}`);
    if (!isSupabaseConfigured) return;
    supabase
      .from("products")
      .delete()
      .eq("id", pid)
      .then(({ error }) => logErr("products.delete", error));
  },
  adjustStock: (pid, delta, reason) => {
    const product = get().products.find((p) => p.id === pid);
    if (!product) return;
    const newStock = Math.max(0, product.stockPieces + delta);
    set({
      products: get().products.map((p) =>
        p.id === pid ? { ...p, stockPieces: newStock } : p
      ),
    });
    get().log("stock.adjust", `Adjusted ${pid} by ${delta} pcs (${reason})`);
    if (!isSupabaseConfigured) return;
    supabase
      .from("products")
      .update({ stock_pieces: newStock })
      .eq("id", pid)
      .then(({ error }) => logErr("products.adjustStock", error));
    supabase
      .from("inventory_transactions")
      .insert({
        product_id: pid,
        type: delta >= 0 ? "in" : "out",
        qty: Math.abs(delta),
        note: reason,
        user_id: get().currentUserId,
      })
      .then(({ error }) => logErr("inv_tx.insert", error));
  },

  /* ------------------------ suppliers ------------------------------ */
  addSupplier: (s) => {
    const tempId = localId("s");
    const ns: Supplier = { ...s, id: tempId };
    set({ suppliers: [...get().suppliers, ns] });
    get().log("supplier.create", `Added supplier ${ns.name}`);
    if (!isSupabaseConfigured) return;
    supabase
      .from("suppliers")
      .insert(supplierToRow(s))
      .select()
      .single()
      .then(({ data, error }) => {
        logErr("suppliers.insert", error);
        if (data) {
          const real = rowToSupplier(data as SupplierRow);
          set({
            suppliers: get().suppliers.map((x) => (x.id === tempId ? real : x)),
          });
        }
      });
  },
  updateSupplier: (sid, patch) => {
    set({
      suppliers: get().suppliers.map((s) =>
        s.id === sid ? { ...s, ...patch } : s
      ),
    });
    if (!isSupabaseConfigured) return;
    supabase
      .from("suppliers")
      .update(supplierToRow(patch))
      .eq("id", sid)
      .then(({ error }) => logErr("suppliers.update", error));
  },
  deleteSupplier: (sid) => {
    set({ suppliers: get().suppliers.filter((s) => s.id !== sid) });
    if (!isSupabaseConfigured) return;
    supabase
      .from("suppliers")
      .delete()
      .eq("id", sid)
      .then(({ error }) => logErr("suppliers.delete", error));
  },

  /* ------------------------ sales ---------------------------------- */
  addSale: (items, paymentMethod, customerId) => {
    const total = items.reduce((s, x) => s + x.total, 0);
    const profit = items.reduce((s, x) => s + x.profit, 0);
    const localSaleId = localId("sl");
    const sale: Sale = {
      id: localSaleId,
      date: new Date().toISOString(),
      items,
      total,
      profit,
      paymentMethod,
      customerId,
      cashierId: get().currentUserId ?? "",
    };
    // optimistic
    const products = get().products.map((p) => {
      const it = items.find((x) => x.productId === p.id);
      if (!it) return p;
      return { ...p, stockPieces: Math.max(0, p.stockPieces - it.qty) };
    });
    let creditTx = get().creditTx;
    let customers = get().customers;
    if (paymentMethod === "credit" && customerId) {
      customers = customers.map((c) =>
        c.id === customerId ? { ...c, balance: c.balance + total } : c
      );
      creditTx = [
        ...creditTx,
        {
          id: localId("ct"),
          customerId,
          date: sale.date,
          type: "sale",
          amount: total,
          saleId: sale.id,
        },
      ];
    }
    set({
      sales: [sale, ...get().sales],
      products,
      customers,
      creditTx,
    });
    get().log(
      "sale.create",
      `Sale ${sale.id} total ${total.toFixed(2)} (${paymentMethod})`
    );

    if (isSupabaseConfigured) {
      void (async () => {
        const { data: saleRow, error: saleErr } = await supabase
          .from("sales")
          .insert({
            customer_id: customerId ?? null,
            payment_method: paymentMethod,
            total,
            profit,
            user_id: get().currentUserId,
          })
          .select()
          .single();
        logErr("sales.insert", saleErr);
        if (!saleRow) return;
        const realId = (saleRow as { id: string }).id;
        const itemsRows = items.map((it) => ({
          sale_id: realId,
          product_id: it.productId,
          qty: it.qty,
          unit_type: it.unit,
          unit_price: it.price,
          landed_cost: it.landedCost,
          line_total: it.total,
          line_profit: it.profit,
        }));
        const { error: siErr } = await supabase.from("sale_items").insert(itemsRows);
        logErr("sale_items.insert", siErr);
        // update each product stock
        for (const it of items) {
          const p = get().products.find((pp) => pp.id === it.productId);
          if (!p) continue;
          await supabase
            .from("products")
            .update({ stock_pieces: p.stockPieces })
            .eq("id", it.productId);
        }
        if (paymentMethod === "credit" && customerId) {
          const c = get().customers.find((x) => x.id === customerId);
          if (c) {
            await supabase
              .from("customers")
              .update({ balance: c.balance })
              .eq("id", customerId);
            await supabase.from("credit_transactions").insert({
              customer_id: customerId,
              type: "sale",
              amount: total,
              sale_id: realId,
              user_id: get().currentUserId,
            });
          }
        }
        // swap local id for real id
        set({
          sales: get().sales.map((s) =>
            s.id === localSaleId ? { ...s, id: realId } : s
          ),
        });
      })();
    }
    return sale;
  },

  voidSale: (id, reason) => {
    const me = get().users.find((u) => u.id === get().currentUserId);
    if (!me || me.role !== "admin") {
      return { ok: false, error: "Only admin can void a sale" };
    }
    const sale = get().sales.find((s) => s.id === id);
    if (!sale) return { ok: false, error: "Sale not found" };
    if (sale.voided) return { ok: false, error: "Sale already voided" };
    const now = new Date().toISOString();
    // Restore stock
    const products = get().products.map((p) => {
      const it = sale.items.find((x) => x.productId === p.id);
      if (!it) return p;
      return { ...p, stockPieces: p.stockPieces + it.qty };
    });
    // Reverse credit if needed
    let customers = get().customers;
    let creditTx = get().creditTx;
    if (sale.paymentMethod === "credit" && sale.customerId) {
      customers = customers.map((c) =>
        c.id === sale.customerId
          ? { ...c, balance: Math.max(0, c.balance - sale.total) }
          : c
      );
      creditTx = [
        ...creditTx,
        {
          id: localId("ct"),
          customerId: sale.customerId,
          date: now,
          type: "payment",
          amount: sale.total,
          saleId: sale.id,
          note: `Sale voided: ${reason}`,
        },
      ];
    }
    set({
      sales: get().sales.map((s) =>
        s.id === id
          ? {
              ...s,
              voided: true,
              voidedAt: now,
              voidedBy: me.id,
              voidedByName: me.fullName,
              voidReason: reason,
            }
          : s
      ),
      products,
      customers,
      creditTx,
    });
    get().log(
      "sale.void",
      `Voided sale #${id.slice(-8).toUpperCase()} — total ${sale.total.toFixed(2)} — reason: ${reason}`
    );
    if (isSupabaseConfigured) {
      // Persist void metadata on the sale itself (best-effort: columns may
      // not exist on every deployment, so we ignore PGRST204-style errors).
      void supabase
        .from("sales")
        .update({
          voided: true,
          voided_at: now,
          voided_by: me.id,
          void_reason: reason,
        })
        .eq("id", id)
        .then(({ error }) => {
          if (error && !/column .* does not exist|schema cache/i.test(error.message)) {
            logErr("sales.void", error);
          }
        });
      // Restore stock in DB
      void (async () => {
        for (const it of sale.items) {
          const p = get().products.find((pp) => pp.id === it.productId);
          if (!p) continue;
          await supabase
            .from("products")
            .update({ stock_pieces: p.stockPieces })
            .eq("id", it.productId);
        }
        if (sale.paymentMethod === "credit" && sale.customerId) {
          const c = get().customers.find((x) => x.id === sale.customerId);
          if (c) {
            await supabase
              .from("customers")
              .update({ balance: c.balance })
              .eq("id", sale.customerId);
            await supabase.from("credit_transactions").insert({
              customer_id: sale.customerId,
              type: "payment",
              amount: sale.total,
              sale_id: sale.id,
              note: `Sale voided: ${reason}`,
              user_id: me.id,
            });
          }
        }
      })();
    }
    return { ok: true };
  },

  editSale: (id, patch, reason) => {
    const me = get().users.find((u) => u.id === get().currentUserId);
    if (!me || me.role !== "admin") {
      return { ok: false, error: "Only admin can edit a sale" };
    }
    const sale = get().sales.find((s) => s.id === id);
    if (!sale) return { ok: false, error: "Sale not found" };
    if (sale.voided) return { ok: false, error: "Cannot edit a voided sale" };
    const before: string[] = [];
    const after: string[] = [];
    if (
      patch.paymentMethod !== undefined &&
      patch.paymentMethod !== sale.paymentMethod
    ) {
      before.push(`payment=${sale.paymentMethod}`);
      after.push(`payment=${patch.paymentMethod}`);
    }
    if (
      patch.customerId !== undefined &&
      patch.customerId !== (sale.customerId ?? "")
    ) {
      before.push(`customer=${sale.customerId ?? "-"}`);
      after.push(`customer=${patch.customerId || "-"}`);
    }
    if (before.length === 0) return { ok: false, error: "No changes" };
    const now = new Date().toISOString();
    set({
      sales: get().sales.map((s) =>
        s.id === id
          ? {
              ...s,
              paymentMethod: patch.paymentMethod ?? s.paymentMethod,
              customerId:
                patch.customerId !== undefined
                  ? patch.customerId || undefined
                  : s.customerId,
              editedAt: now,
              editedBy: me.id,
              editedByName: me.fullName,
            }
          : s
      ),
    });
    get().log(
      "sale.edit",
      `Edited sale #${id.slice(-8).toUpperCase()} — ${before.join(", ")} → ${after.join(", ")} — reason: ${reason}`
    );
    if (isSupabaseConfigured) {
      const row: Record<string, unknown> = {};
      if (patch.paymentMethod !== undefined) row.payment_method = patch.paymentMethod;
      if (patch.customerId !== undefined) row.customer_id = patch.customerId || null;
      // Best-effort audit metadata; ignore if columns are not deployed.
      row.edited_at = now;
      row.edited_by = me.id;
      if (Object.keys(row).length > 0) {
        supabase
          .from("sales")
          .update(row)
          .eq("id", id)
          .then(({ error }) => {
            if (
              error &&
              !/column .* does not exist|schema cache/i.test(error.message)
            ) {
              logErr("sales.edit", error);
            }
          });
      }
    }
    return { ok: true };
  },

  /* ------------------------ damaged -------------------------------- */
  addDamaged: (d) => {
    const product = get().products.find((p) => p.id === d.productId);
    const stockBefore = product?.stockPieces ?? 0;
    const stockAfter = Math.max(0, stockBefore - d.qty);
    const lcpp = product ? landedCostPerPiece(product) : 0;
    const valueLoss = d.qty * lcpp;
    const userId = get().currentUserId ?? "";
    const userName =
      get().users.find((u) => u.id === userId)?.fullName ?? "System";
    const tempId = localId("d");
    const damaged: DamagedItem = {
      ...d,
      valueLoss,
      id: tempId,
      reportedBy: userId,
      reportedByName: userName,
      landedCostPerPiece: lcpp,
      stockBefore,
      stockAfter,
      barcode: product?.barcode,
      date: new Date().toISOString(),
    };
    set({
      damaged: [damaged, ...get().damaged],
      products: get().products.map((p) =>
        p.id === d.productId ? { ...p, stockPieces: stockAfter } : p
      ),
    });
    get().log(
      "damage.create",
      `Reported ${d.qty} pcs damaged of ${d.name} \u2014 loss ${valueLoss.toFixed(2)}`
    );
    if (!isSupabaseConfigured) return;
    void (async () => {
      const { data, error } = await supabase
        .from("damaged_items")
        .insert({
          product_id: d.productId,
          qty: d.qty,
          unit_type: d.unit,
          reason: d.reason,
          landed_cost_per_unit: lcpp,
          loss_amount: valueLoss,
          stock_before: stockBefore,
          stock_after: stockAfter,
          user_id: userId || null,
          notes: d.notes ?? null,
        })
        .select()
        .single();
      logErr("damaged.insert", error);
      if (data) {
        const realId = (data as { id: string }).id;
        set({
          damaged: get().damaged.map((x) =>
            x.id === tempId ? { ...x, id: realId } : x
          ),
        });
      }
      await supabase
        .from("products")
        .update({ stock_pieces: stockAfter })
        .eq("id", d.productId);
    })();
  },

  /* ------------------------ orders --------------------------------- */
  addOrder: (supplierId, items, notes) => {
    const tempId = localId("o");
    const order: Order = {
      id: tempId,
      supplierId,
      date: new Date().toISOString(),
      items,
      status: "pending",
      notes,
    };
    set({ orders: [order, ...get().orders] });
    get().log("order.create", `Created order ${order.id}`);
    if (isSupabaseConfigured) {
      void (async () => {
        const { data, error } = await supabase
          .from("orders")
          .insert({ supplier_id: supplierId, notes: notes ?? null })
          .select()
          .single();
        logErr("orders.insert", error);
        if (!data) return;
        const realId = (data as { id: string }).id;
        const itemsRows = items.map((it) => ({
          order_id: realId,
          product_id: it.productId,
          qty: it.qty,
          unit_type: it.unit,
          received_qty: it.receivedQty,
          notes: it.notes ?? null,
        }));
        const { error: oiErr } = await supabase.from("order_items").insert(itemsRows);
        logErr("order_items.insert", oiErr);
        set({
          orders: get().orders.map((o) =>
            o.id === tempId ? { ...o, id: realId } : o
          ),
        });
      })();
    }
    return order;
  },
  updateOrder: (oid, patch) => {
    set({
      orders: get().orders.map((o) => (o.id === oid ? { ...o, ...patch } : o)),
    });
    if (!isSupabaseConfigured) return;
    const row: Record<string, unknown> = {};
    if (patch.status !== undefined) row.status = patch.status;
    if (patch.boatName !== undefined) row.boat_name = patch.boatName;
    if (patch.boatContact !== undefined) row.boat_contact = patch.boatContact;
    if (patch.loadingDate !== undefined) row.loading_date = patch.loadingDate;
    if (patch.sentDate !== undefined) row.sent_date = patch.sentDate;
    if (patch.expectedDate !== undefined) row.expected_date = patch.expectedDate;
    if (patch.receivedDate !== undefined) row.received_date = patch.receivedDate;
    if (patch.notes !== undefined) row.notes = patch.notes;
    if (Object.keys(row).length > 0) {
      supabase
        .from("orders")
        .update(row)
        .eq("id", oid)
        .then(({ error }) => logErr("orders.update", error));
    }
  },
  receiveOrderItem: (oid, pid, receivedQty) => {
    const order = get().orders.find((o) => o.id === oid);
    if (!order) return;
    const item = order.items.find((i) => i.productId === pid);
    if (!item) return;
    const delta = receivedQty - item.receivedQty;
    set({
      orders: get().orders.map((o) =>
        o.id === oid
          ? {
              ...o,
              items: o.items.map((i) =>
                i.productId === pid ? { ...i, receivedQty } : i
              ),
            }
          : o
      ),
      products: get().products.map((p) =>
        p.id === pid
          ? { ...p, stockPieces: Math.max(0, p.stockPieces + delta) }
          : p
      ),
    });
    get().log(
      "order.receive",
      `Received ${receivedQty} pcs of ${pid} on order ${oid}`
    );
    if (!isSupabaseConfigured) return;
    supabase
      .from("order_items")
      .update({ received_qty: receivedQty })
      .eq("order_id", oid)
      .eq("product_id", pid)
      .then(({ error }) => logErr("order_items.update", error));
    const newStock = get().products.find((p) => p.id === pid)?.stockPieces ?? 0;
    supabase
      .from("products")
      .update({ stock_pieces: newStock })
      .eq("id", pid)
      .then(({ error }) => logErr("products.stock", error));
  },
  markOrderReceived: (oid) => {
    const order = get().orders.find((o) => o.id === oid);
    if (!order) return;
    order.items.forEach((it) => {
      if (it.receivedQty < it.qty) {
        get().receiveOrderItem(oid, it.productId, it.qty);
      }
    });
    get().updateOrder(oid, {
      status: "received",
      receivedDate: new Date().toISOString(),
    });
  },

  /* ------------------------ customers ------------------------------ */
  addCustomer: (c) => {
    const tempId = localId("c");
    const status: CreditApprovalStatus = c.approvalStatus ?? "pending";
    const isApproved = status === "approved";
    const me = get().users.find((u) => u.id === get().currentUserId);
    const nc: CreditCustomer = {
      name: c.name,
      phone: c.phone,
      address: c.address,
      notes: c.notes,
      openingBalance: c.openingBalance,
      requestedCreditLimit: c.requestedCreditLimit ?? c.creditLimit,
      creditLimit: isApproved ? c.creditLimit : 0,
      id: tempId,
      balance: c.openingBalance,
      approvalStatus: status,
      approvedBy: isApproved ? me?.id : undefined,
      approvedByName: isApproved ? me?.fullName : undefined,
      approvedAt: isApproved ? new Date().toISOString() : undefined,
    };
    set({ customers: [...get().customers, nc] });
    if (c.openingBalance > 0) {
      set({
        creditTx: [
          ...get().creditTx,
          {
            id: localId("ct"),
            customerId: nc.id,
            date: new Date().toISOString(),
            type: "sale",
            amount: c.openingBalance,
            note: "Opening balance",
          },
        ],
      });
    }
    get().log(
      "customer.create",
      `Added customer ${nc.name} (status: ${status})`
    );
    if (!isSupabaseConfigured) return;
    void (async () => {
      const { data, error } = await supabase
        .from("customers")
        .insert({
          name: c.name,
          phone: c.phone || null,
          address: c.address || null,
          opening_balance: c.openingBalance,
          credit_limit: nc.creditLimit,
          requested_credit_limit: nc.requestedCreditLimit ?? 0,
          balance: c.openingBalance,
          notes: c.notes || null,
          approval_status: status,
          approved_by: nc.approvedBy ?? null,
          approved_at: nc.approvedAt ?? null,
        })
        .select()
        .single();
      logErr("customers.insert", error);
      if (!data) return;
      const realId = (data as { id: string }).id;
      set({
        customers: get().customers.map((x) =>
          x.id === tempId ? { ...x, id: realId } : x
        ),
      });
      if (c.openingBalance > 0) {
        await supabase.from("credit_transactions").insert({
          customer_id: realId,
          type: "sale",
          amount: c.openingBalance,
          note: "Opening balance",
          user_id: get().currentUserId,
        });
      }
    })();
  },

  approveCustomer: (cid, finalLimit) => {
    const me = get().users.find((u) => u.id === get().currentUserId);
    const approvedAt = new Date().toISOString();
    set({
      customers: get().customers.map((c) =>
        c.id === cid
          ? {
              ...c,
              approvalStatus: "approved",
              creditLimit: finalLimit,
              approvedBy: me?.id,
              approvedByName: me?.fullName,
              approvedAt,
            }
          : c
      ),
    });
    get().log(
      "customer.approve",
      `Approved credit customer ${cid} with limit ${finalLimit}`
    );
    if (!isSupabaseConfigured) return;
    supabase
      .from("customers")
      .update({
        approval_status: "approved",
        credit_limit: finalLimit,
        approved_by: me?.id ?? null,
        approved_at: approvedAt,
      })
      .eq("id", cid)
      .then(({ error }) => logErr("customers.approve", error));
  },

  rejectCustomer: (cid) => {
    const me = get().users.find((u) => u.id === get().currentUserId);
    const approvedAt = new Date().toISOString();
    set({
      customers: get().customers.map((c) =>
        c.id === cid
          ? {
              ...c,
              approvalStatus: "rejected",
              creditLimit: 0,
              approvedBy: me?.id,
              approvedByName: me?.fullName,
              approvedAt,
            }
          : c
      ),
    });
    get().log("customer.reject", `Rejected credit customer ${cid}`);
    if (!isSupabaseConfigured) return;
    supabase
      .from("customers")
      .update({
        approval_status: "rejected",
        credit_limit: 0,
        approved_by: me?.id ?? null,
        approved_at: approvedAt,
      })
      .eq("id", cid)
      .then(({ error }) => logErr("customers.reject", error));
  },
  updateCustomer: (cid, patch) => {
    set({
      customers: get().customers.map((c) =>
        c.id === cid ? { ...c, ...patch } : c
      ),
    });
    if (!isSupabaseConfigured) return;
    const row: Record<string, unknown> = {};
    if (patch.name !== undefined) row.name = patch.name;
    if (patch.phone !== undefined) row.phone = patch.phone;
    if (patch.address !== undefined) row.address = patch.address;
    if (patch.creditLimit !== undefined) row.credit_limit = patch.creditLimit;
    if (patch.requestedCreditLimit !== undefined) row.requested_credit_limit = patch.requestedCreditLimit;
    if (patch.approvalStatus !== undefined) row.approval_status = patch.approvalStatus;
    if (patch.notes !== undefined) row.notes = patch.notes;
    if (patch.balance !== undefined) row.balance = patch.balance;
    if (Object.keys(row).length > 0) {
      supabase
        .from("customers")
        .update(row)
        .eq("id", cid)
        .then(({ error }) => logErr("customers.update", error));
    }
  },
  deleteCustomer: (cid) => {
    set({ customers: get().customers.filter((c) => c.id !== cid) });
    if (!isSupabaseConfigured) return;
    supabase
      .from("customers")
      .delete()
      .eq("id", cid)
      .then(({ error }) => logErr("customers.delete", error));
  },
  addCreditPayment: (cid, amount, note) => {
    const c = get().customers.find((x) => x.id === cid);
    const newBalance = Math.max(0, (c?.balance ?? 0) - amount);
    set({
      customers: get().customers.map((cc) =>
        cc.id === cid ? { ...cc, balance: newBalance } : cc
      ),
      creditTx: [
        ...get().creditTx,
        {
          id: localId("ct"),
          customerId: cid,
          date: new Date().toISOString(),
          type: "payment",
          amount,
          note,
        },
      ],
    });
    get().log("credit.payment", `Received ${amount.toFixed(2)} from ${cid}`);
    if (!isSupabaseConfigured) return;
    supabase
      .from("customers")
      .update({ balance: newBalance })
      .eq("id", cid)
      .then(({ error }) => logErr("customers.balance", error));
    supabase
      .from("credit_transactions")
      .insert({
        customer_id: cid,
        type: "payment",
        amount,
        note: note ?? null,
        user_id: get().currentUserId,
      })
      .then(({ error }) => logErr("credit_tx.insert", error));
  },

  /* ------------------------ logging -------------------------------- */
  log: (action, detail) => {
    const u = get().users.find((x) => x.id === get().currentUserId);
    const entry: ActivityLog = {
      id: localId("lg"),
      date: new Date().toISOString(),
      userId: u?.id ?? "system",
      userName: u?.fullName ?? "System",
      action,
      detail,
    };
    set({ logs: [entry, ...get().logs].slice(0, 500) });
    if (!isSupabaseConfigured) return;
    supabase
      .from("activity_logs")
      .insert({
        user_id: u?.id ?? null,
        action,
        entity: action.split(".")[0] ?? null,
        meta: { detail },
      })
      .then(({ error }) => logErr("activity_logs.insert", error));
  },

  resetData: () => set({ ...initial, currentUserId: get().currentUserId }),
}));

export const useCurrentUser = (): User | null => {
  const id = useStore((s) => s.currentUserId);
  const users = useStore((s) => s.users);
  return users.find((u) => u.id === id) ?? null;
};
