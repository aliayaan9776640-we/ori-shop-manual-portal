import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useStore, useCurrentUser } from "@/lib/store";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import Layout from "@/components/Layout";
import RoleGate from "@/components/RoleGate";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Inventory from "./pages/Inventory";
import Sales from "./pages/Sales";
import Suppliers from "./pages/Suppliers";
import Orders from "./pages/Orders";
import Damaged from "./pages/Damaged";
import Customers from "./pages/Customers";
import Reports from "./pages/Reports";
import Users from "./pages/Users";
import Settings from "./pages/Settings";
import Quotations from "./pages/Quotations";
import BillHistory from "./pages/BillHistory";
import CashDrawerPage from "./pages/CashDrawer";
import BackupPage from "./pages/Backup";
import NotFound from "./pages/NotFound";
import ResetPassword from "./pages/ResetPassword";
import { useEffect, type ReactNode } from "react";
import Logo from "@/components/Logo";
import { runDailyAutoBackupIfDue } from "@/lib/backup";

const queryClient = new QueryClient();

function NotConfiguredScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-6">
      <div className="max-w-md w-full rounded-lg border border-destructive/40 bg-destructive/5 p-6 text-center">
        <Logo size={56} ring />
        <h1 className="mt-4 text-xl font-semibold text-destructive">
          System not configured
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Supabase credentials are missing. Set
          <code className="mx-1 rounded bg-muted px-1 py-0.5 text-xs">VITE_SUPABASE_URL</code>
          and
          <code className="mx-1 rounded bg-muted px-1 py-0.5 text-xs">VITE_SUPABASE_ANON_KEY</code>
          in your environment, then rebuild the app.
        </p>
      </div>
    </div>
  );
}

function RequireAuth({ children }: { children: ReactNode }) {
  const user = useCurrentUser();
  const hydrated = useStore((s) => s.hydrated);
  if (!hydrated && isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Logo size={56} ring />
          <div className="text-sm text-muted-foreground">Loading portal…</div>
        </div>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  if (!user.active) {
    if (isSupabaseConfigured) void supabase.auth.signOut();
    useStore.setState({ currentUserId: null });
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

function AuthBootstrap() {
  const bootstrap = useStore((s) => s.bootstrap);
  useEffect(() => {
    void bootstrap();

    // Daily automatic backup: runs once per session if 24h have elapsed,
    // and re-checks hourly + on window focus.
    let backupInterval: number | null = null;
    const onFocus = (): void => {
      runDailyAutoBackupIfDue();
    };
    try {
      runDailyAutoBackupIfDue();
      backupInterval = window.setInterval(() => {
        runDailyAutoBackupIfDue();
      }, 60 * 60 * 1000);
      window.addEventListener("focus", onFocus);
    } catch (e) {
      console.error("[backup] init failed", e);
    }

    const sub = isSupabaseConfigured
      ? supabase.auth.onAuthStateChange((event, session) => {
          // Don't hijack a password-recovery session as a normal login.
          if (event === "PASSWORD_RECOVERY") {
            console.log("[auth] password recovery session detected");
            return;
          }
          if (window.location.pathname.startsWith("/reset-password")) {
            return;
          }
          if (event === "SIGNED_OUT") {
            useStore.setState({ currentUserId: null });
            return;
          }
          if (session?.user) {
            // If the user has been deactivated, immediately revoke the session
            // even if it was restored from storage.
            const me = useStore
              .getState()
              .users.find((u) => u.id === session.user.id);
            if (me && !me.active) {
              console.warn("[auth] inactive user detected, signing out", me.email);
              void supabase.auth.signOut();
              useStore.setState({ currentUserId: null });
              return;
            }
            useStore.setState({ currentUserId: session.user.id });
          }
        })
      : null;

    return () => {
      if (backupInterval !== null) window.clearInterval(backupInterval);
      window.removeEventListener("focus", onFocus);
      sub?.data.subscription.unsubscribe();
    };
  }, [bootstrap]);
  return null;
}

const App = () => {
  if (!isSupabaseConfigured) {
    console.error(
      "[App] Supabase env missing. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY."
    );
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner position="top-right" richColors />
          <NotConfiguredScreen />
        </TooltipProvider>
      </QueryClientProvider>
    );
  }
  return (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner position="top-right" richColors />
      <BrowserRouter>
        <AuthBootstrap />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route
            element={
              <RequireAuth>
                <Layout />
              </RequireAuth>
            }
          >
            <Route path="/" element={<Dashboard />} />
            <Route path="/inventory" element={<Inventory />} />
            <Route
              path="/sales"
              element={
                <RoleGate roles={["admin", "cashier"]}>
                  <Sales />
                </RoleGate>
              }
            />
            <Route
              path="/bills"
              element={
                <RoleGate roles={["admin", "cashier"]}>
                  <BillHistory />
                </RoleGate>
              }
            />
            <Route
              path="/quotations"
              element={
                <RoleGate roles={["admin", "cashier"]}>
                  <Quotations />
                </RoleGate>
              }
            />
            <Route
              path="/cash-drawer"
              element={
                <RoleGate roles={["admin", "cashier"]}>
                  <CashDrawerPage />
                </RoleGate>
              }
            />
            <Route
              path="/suppliers"
              element={
                <RoleGate roles={["admin", "storekeeper"]}>
                  <Suppliers />
                </RoleGate>
              }
            />
            <Route
              path="/orders"
              element={
                <RoleGate roles={["admin", "storekeeper"]}>
                  <Orders />
                </RoleGate>
              }
            />
            <Route
              path="/damaged"
              element={
                <RoleGate roles={["admin", "storekeeper"]}>
                  <Damaged />
                </RoleGate>
              }
            />
            <Route
              path="/customers"
              element={
                <RoleGate roles={["admin", "cashier"]}>
                  <Customers />
                </RoleGate>
              }
            />
            <Route
              path="/reports"
              element={
                <RoleGate roles={["admin"]}>
                  <Reports />
                </RoleGate>
              }
            />
            <Route
              path="/users"
              element={
                <RoleGate roles={["admin"]}>
                  <Users />
                </RoleGate>
              }
            />
            <Route
              path="/settings"
              element={
                <RoleGate roles={["admin"]}>
                  <Settings />
                </RoleGate>
              }
            />
            <Route
              path="/backup"
              element={
                <RoleGate roles={["admin"]}>
                  <BackupPage />
                </RoleGate>
              }
            />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
  );
};

export default App;
