import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { useStore } from "@/lib/store";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";
import { Lock, Mail, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";
import { toast } from "sonner";

export default function Login() {
  const login = useStore((s) => s.login);
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: FormEvent): Promise<void> => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await login(email.trim(), password);
    setLoading(false);
    if (!res.ok) {
      setError(res.error ?? "Login failed");
      return;
    }
    navigate("/");
  };

  const onForgot = async (): Promise<void> => {
    if (!isSupabaseConfigured) {
      toast.error("Supabase is not configured.");
      return;
    }
    const target = (email || window.prompt("Enter your account email to receive a reset link:") || "").trim();
    if (!target) return;
    const redirectTo = `${window.location.origin}/reset-password`;
    console.log("[forgot-password] sending reset for", target, "redirectTo", redirectTo);
    const { error: resetErr } = await supabase.auth.resetPasswordForEmail(target, { redirectTo });
    if (resetErr) {
      toast.error(resetErr.message);
      return;
    }
    toast.success(`Reset link sent to ${target}. Check your inbox.`);
  };

  return (
    <div className="relative grid min-h-screen lg:grid-cols-2">
      {/* Left brand panel */}
      <div className="relative hidden overflow-hidden bg-[hsl(80,25%,10%)] text-white lg:block">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "radial-gradient(circle at 20% 20%, hsl(25 90% 55% / 0.35), transparent 45%), radial-gradient(circle at 80% 80%, hsl(75 50% 35% / 0.35), transparent 45%)",
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: `url('https://pub-e001eb4506b145aa938b5d3badbff6a5.r2.dev/attachments/33rbc3xbwihdsvk0yelbx.jpeg')`,
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center",
            backgroundSize: "70%",
          }}
        />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent_0%,hsl(80,25%,7%)_100%)]" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <div className="flex items-center gap-3">
            <Logo size={56} ring />
            <div>
              <div className="text-lg font-bold tracking-tight">Ori Barakah Store</div>
              <div className="text-xs uppercase tracking-widest text-white/60">
                Ori Brothers · Since 2025
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h1 className="text-4xl font-bold leading-tight">
              Run your shop with{" "}
              <span className="bg-gradient-to-r from-orange-300 to-orange-500 bg-clip-text text-transparent">
                clarity & barakah.
              </span>
            </h1>
            <p className="max-w-md text-base text-white/70">
              Inventory, sales, supplier orders, boat loading, and credit customers — one
              secure portal for the whole team.
            </p>

            <div className="grid grid-cols-2 gap-3">
              {[
                { k: "Live", v: "Stock tracking" },
                { k: "1-Tap", v: "Viber orders" },
                { k: "Auto", v: "Profit calc" },
                { k: "Role", v: "Based access" },
              ].map((b) => (
                <div
                  key={b.v}
                  className="rounded-xl border border-white/10 bg-white/5 p-4 backdrop-blur"
                >
                  <div className="text-2xl font-bold text-orange-400">{b.k}</div>
                  <div className="text-sm text-white/70">{b.v}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="text-xs text-white/50">
            © {new Date().getFullYear()} Ori Barakah Store · Ori Brothers
          </div>
        </div>
      </div>

      {/* Right form */}
      <div className="flex items-center justify-center bg-background p-6 sm:p-12">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <Logo size={44} />
            <div>
              <div className="font-bold">Ori Barakah Store</div>
              <div className="text-xs text-muted-foreground">Ori Brothers · Portal</div>
            </div>
          </div>

          <h2 className="text-2xl font-bold tracking-tight">Sign in to your account</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Enter your credentials to access the portal.
          </p>

          <form onSubmit={onSubmit} className="mt-8 space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@oribrothers.com"
                  autoComplete="email"
                  className="h-11 w-full rounded-lg border border-input bg-background pl-10 pr-3 text-sm outline-none ring-offset-background transition focus-visible:ring-2 focus-visible:ring-ring"
                  required
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="h-11 w-full rounded-lg border border-input bg-background pl-10 pr-3 text-sm outline-none ring-offset-background transition focus-visible:ring-2 focus-visible:ring-ring"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                <AlertCircle className="h-4 w-4" />
                {error}
              </div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="h-11 w-full bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {loading ? "Signing in..." : "Sign in"}
            </Button>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={onForgot}
                className="text-xs font-medium text-muted-foreground hover:text-foreground hover:underline"
              >
                Forgot password?
              </button>
            </div>
          </form>

          {!isSupabaseConfigured && (
            <div className="mt-8 rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-sm text-destructive">
              Supabase is not configured. Login is disabled until
              <code className="mx-1 rounded bg-destructive/20 px-1 py-0.5 text-xs">VITE_SUPABASE_URL</code>
              and
              <code className="mx-1 rounded bg-destructive/20 px-1 py-0.5 text-xs">VITE_SUPABASE_ANON_KEY</code>
              are set.
            </div>
          )}
          {isSupabaseConfigured && (
            <p className="mt-6 text-xs text-muted-foreground">
              Connected to Supabase · ask your admin to create your account.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
