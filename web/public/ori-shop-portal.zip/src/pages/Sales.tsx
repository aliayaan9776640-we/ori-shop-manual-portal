import { useMemo, useState } from "react";
import { useStore, landedCostPerPiece, useCurrentUser } from "@/lib/store";
import type { PaymentMethod, SaleItem } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { formatCurrency, formatDateTime, isSameDay } from "@/lib/format";
import {
  Search,
  Trash2,
  Receipt,
  CreditCard,
  Banknote,
  Building2,
  HandCoins,
  Printer,
  Plus,
  Minus,
  X,
  User as UserIcon,
  ScanLine,
  Save,
} from "lucide-react";
import { toast } from "sonner";
import { useSettings } from "@/lib/settings";
import { printReceipt as printReceiptDoc, downloadReceiptHtml, type ReceiptData } from "@/lib/receipt";
import { useCashDrawers } from "@/lib/cashDrawer";

interface CartLine {
  productId: string;
  name: string;
  unitQty: number;
  pieces: number;
  pricePerPiece: number;
  costPerPiece: number;
  unit: string;
  piecesPerCase: number;
  gstApplicable: boolean;
}

export default function Sales() {
  const products = useStore((s) => s.products);
  const sales = useStore((s) => s.sales);
  const customers = useStore((s) => s.customers);
  const addSale = useStore((s) => s.addSale);
  const user = useCurrentUser();
  const isAdmin = user?.role === "admin";

  const settings = useSettings();

  const [search, setSearch] = useState("");
  const [customerQuery, setCustomerQuery] = useState("");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [payment, setPayment] = useState<PaymentMethod>("cash");
  const [customerId, setCustomerId] = useState<string>("");
  const [bagCount, setBagCount] = useState<number>(0);
  const [discount, setDiscount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<string>("");

  const drawers = useCashDrawers((s) => s.drawers);
  const openDrawer = drawers.find(
    (d) => d.cashierId === user?.id && d.status === "open"
  );

  // Editable per-sale tax/fee overrides (defaults from admin settings)
  const [gstPercent, setGstPercent] = useState<number>(settings.gstPercent);
  const [gstEnabled, setGstEnabled] = useState<boolean>(settings.gstEnabled);
  const [cardPct, setCardPct] = useState<number>(settings.cardChargePercent);
  const [bagFeeUnit, setBagFeeUnit] = useState<number>(settings.plasticBagFee);

  const [lastReceipt, setLastReceipt] = useState<ReceiptData | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return [] as typeof products;
    return products
      .filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.barcode.toLowerCase().includes(q)
      )
      .slice(0, 8);
  }, [products, search]);

  const filteredCustomers = useMemo(() => {
    const q = customerQuery.trim().toLowerCase();
    if (!q) return [] as typeof customers;
    // Only approved customers can be selected for credit sales
    return customers
      .filter((c) => c.approvalStatus === "approved")
      .filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          (c.phone || "").toLowerCase().includes(q)
      )
      .slice(0, 6);
  }, [customers, customerQuery]);

  const todaysSales = useMemo(
    () => sales.filter((s) => isSameDay(s.date, new Date())),
    [sales]
  );
  const todaysTotal = todaysSales.reduce((s, x) => s + x.total, 0);
  const todaysProfit = todaysSales.reduce((s, x) => s + x.profit, 0);

  // Recent / fast-moving items: prefer items sold today, fallback to last 7 days
  const recentItems = useMemo(() => {
    interface Agg {
      productId: string;
      name: string;
      qty: number;
      lastDate: string;
    }
    const since = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const map = new Map<string, Agg>();
    for (const s of sales) {
      if (new Date(s.date).getTime() < since) continue;
      for (const it of s.items) {
        const ex = map.get(it.productId);
        if (ex) {
          ex.qty += it.qty;
          if (new Date(s.date) > new Date(ex.lastDate)) ex.lastDate = s.date;
        } else {
          map.set(it.productId, {
            productId: it.productId,
            name: it.name,
            qty: it.qty,
            lastDate: s.date,
          });
        }
      }
    }
    return Array.from(map.values())
      .sort((a, b) => new Date(b.lastDate).getTime() - new Date(a.lastDate).getTime())
      .slice(0, 8);
  }, [sales]);

  const addToCart = (productId: string): void => {
    const p = products.find((x) => x.id === productId);
    if (!p) return;
    if (p.stockPieces <= 0) {
      toast.error(`${p.name} is out of stock`);
      return;
    }
    setCart((prev) => {
      const existing = prev.find((c) => c.productId === productId);
      if (existing) {
        return prev.map((c) =>
          c.productId === productId
            ? {
                ...c,
                unitQty: c.unitQty + 1,
                pieces: c.pieces + Math.max(1, p.piecesPerCase),
              }
            : c
        );
      }
      const ppCase = Math.max(1, p.piecesPerCase);
      return [
        ...prev,
        {
          productId: p.id,
          name: p.name,
          unitQty: 1,
          pieces: ppCase,
          pricePerPiece: p.sellingPrice / ppCase,
          costPerPiece: landedCostPerPiece(p),
          unit: p.unit,
          piecesPerCase: ppCase,
          gstApplicable: p.gstApplicable !== false,
        },
      ];
    });
    setSearch("");
  };

  const setQty = (productId: string, unitQty: number): void => {
    setCart((prev) =>
      prev
        .map((c) =>
          c.productId === productId
            ? {
                ...c,
                unitQty,
                pieces: Math.max(0, unitQty) * c.piecesPerCase,
              }
            : c
        )
        .filter((c) => c.unitQty > 0)
    );
  };

  const incQty = (productId: string): void => {
    const c = cart.find((x) => x.productId === productId);
    if (!c) return;
    setQty(productId, c.unitQty + 1);
  };
  const decQty = (productId: string): void => {
    const c = cart.find((x) => x.productId === productId);
    if (!c) return;
    setQty(productId, Math.max(0, c.unitQty - 1));
  };

  const setLinePrice = (productId: string, pricePerCase: number): void => {
    setCart((prev) =>
      prev.map((c) =>
        c.productId === productId
          ? {
              ...c,
              pricePerPiece: pricePerCase / Math.max(1, c.piecesPerCase),
            }
          : c
      )
    );
  };

  const removeLine = (productId: string): void => {
    setCart((prev) => prev.filter((c) => c.productId !== productId));
  };

  const itemCount = cart.length;
  const totalQty = cart.reduce((s, c) => s + c.unitQty, 0);

  const lineTotal = (c: CartLine): number => c.pieces * c.pricePerPiece;
  const gstSubtotal = cart
    .filter((c) => c.gstApplicable)
    .reduce((s, c) => s + lineTotal(c), 0);
  const nonGstSubtotal = cart
    .filter((c) => !c.gstApplicable)
    .reduce((s, c) => s + lineTotal(c), 0);
  const subtotal = gstSubtotal + nonGstSubtotal;
  const profit = cart.reduce(
    (s, c) => s + c.pieces * (c.pricePerPiece - c.costPerPiece),
    0
  );
  const bagFee = bagCount * bagFeeUnit;
  const discountAmt = Math.min(discount, subtotal);
  // distribute discount proportionally between GST and non-GST items
  const discGst =
    subtotal > 0 ? (discountAmt * gstSubtotal) / subtotal : 0;
  const discNonGst = discountAmt - discGst;
  const taxableGstBase = Math.max(0, gstSubtotal - discGst);
  const taxableNonGstBase = Math.max(0, nonGstSubtotal - discNonGst);
  const taxableBase = taxableGstBase + taxableNonGstBase;
  const gstAmount =
    gstEnabled
      ? +(
          (taxableGstBase + (settings.bagFeeTaxable ? bagFee : 0)) *
          (gstPercent / 100)
        ).toFixed(2)
      : 0;
  const cardFee =
    payment === "card" && cardPct > 0
      ? +(
          ((taxableBase + gstAmount + bagFee) * cardPct) /
          100
        ).toFixed(2)
      : 0;
  const grandTotal = +(
    taxableBase +
    gstAmount +
    bagFee +
    cardFee
  ).toFixed(2);

  const paidNum = Number(paidAmount) || 0;
  const changeAmt = +(paidNum - grandTotal).toFixed(2);
  const remainingAmt = changeAmt < 0 ? Math.abs(changeAmt) : 0;

  const cancelSale = (): void => {
    if (cart.length === 0) return;
    setCart([]);
    setPayment("cash");
    setCustomerId("");
    setCustomerQuery("");
    setBagCount(0);
    setDiscount(0);
    setPaidAmount("");
    toast("Sale cancelled");
  };

  const checkout = (printAfter: boolean): void => {
    if (cart.length === 0) {
      toast.error("Cart is empty");
      return;
    }
    if (payment === "credit") {
      if (!customerId) {
        toast.error("Select a credit customer");
        return;
      }
      const cust = customers.find((c) => c.id === customerId);
      if (!cust) {
        toast.error("Customer not found");
        return;
      }
      if (cust.approvalStatus !== "approved") {
        toast.error(
          `Customer not approved (${cust.approvalStatus}). Admin approval required before credit sale.`
        );
        return;
      }
      const remaining = Math.max(0, cust.creditLimit - cust.balance);
      // grandTotal already computed below; recompute snapshot for clarity
      if (grandTotal > remaining) {
        toast.error(
          `Credit limit exceeded. Remaining: ${formatCurrency(remaining)}`
        );
        return;
      }
    }
    for (const c of cart) {
      const p = products.find((x) => x.id === c.productId);
      if (!p || p.stockPieces < c.pieces) {
        toast.error(`Insufficient stock for ${c.name}`);
        return;
      }
    }
    const items: SaleItem[] = cart.map((c) => ({
      productId: c.productId,
      name: c.name,
      qty: c.pieces,
      unit: c.unit as SaleItem["unit"],
      unitQty: c.unitQty,
      price: c.pricePerPiece,
      landedCost: c.costPerPiece,
      total: c.pieces * c.pricePerPiece,
      profit: c.pieces * (c.pricePerPiece - c.costPerPiece),
      gstApplicable: c.gstApplicable,
    }));
    const sale = addSale(
      items,
      payment,
      payment === "credit" ? customerId : undefined
    );
    const cust = customers.find((c) => c.id === customerId);
    const effectivePaid =
      payment === "credit" ? 0 : paidNum > 0 ? paidNum : grandTotal;
    const effectiveChange =
      payment === "credit" ? 0 : +(effectivePaid - grandTotal).toFixed(2);
    const receipt: ReceiptData = {
      saleId: sale.id,
      invoiceNo: sale.id.slice(-8).toUpperCase(),
      date: sale.date,
      cashierName: user?.fullName,
      customerName: cust?.name,
      customerPhone: cust?.phone,
      items: cart.map((c) => ({
        name: c.name,
        qty: c.pieces,
        price: c.pricePerPiece,
        total: c.pieces * c.pricePerPiece,
        gstApplicable: c.gstApplicable,
      })),
      subtotal,
      gstSubtotal,
      nonGstSubtotal,
      discount: discountAmt,
      bag: bagFee,
      cardFee,
      gstAmount,
      gstPercent,
      total: grandTotal,
      paid: effectivePaid,
      change: effectiveChange,
      payment,
      shopName: settings.shopName,
      footer: settings.receiptFooter,
    };
    setLastReceipt(receipt);
    toast.success(`Sale recorded · ${formatCurrency(grandTotal)}`);
    setCart([]);
    setPayment("cash");
    setCustomerId("");
    setCustomerQuery("");
    setBagCount(0);
    setDiscount(0);
    setPaidAmount("");
    if (printAfter) {
      setTimeout(() => printReceiptDoc(receipt), 50);
    }
  };

  const printReceipt = (r?: ReceiptData): void => {
    const data = r ?? lastReceipt;
    if (!data) {
      toast.error("No receipt to print");
      return;
    }
    printReceiptDoc(data);
  };

  const downloadPdf = (): void => {
    if (!lastReceipt) {
      toast.error("No receipt to download");
      return;
    }
    downloadReceiptHtml(lastReceipt);
    toast.success("Receipt downloaded — open & use 'Save as PDF'");
  };

  const selectedCustomer = customers.find((c) => c.id === customerId);

  return (
    <div className="-mx-4 -my-4 sm:-mx-6 sm:-my-6 flex h-[calc(100vh-4rem)] flex-col bg-slate-50 text-slate-900">
      {/* Top bar */}
      <div className="flex flex-col gap-2 border-b border-slate-200 bg-white px-4 py-3 shadow-sm sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <ScanLine className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && filtered.length > 0) {
                addToCart(filtered[0].id);
              }
            }}
            placeholder="Scan barcode or search item..."
            className="h-12 w-full rounded-lg border border-slate-300 bg-white pl-11 pr-3 text-base font-medium text-slate-900 outline-none placeholder:text-slate-400 focus:border-primary focus:ring-2 focus:ring-primary/30"
            autoFocus
          />
          {search && filtered.length > 0 && (
            <div className="absolute left-0 right-0 top-full z-30 mt-1 max-h-72 overflow-auto rounded-lg border border-slate-200 bg-white shadow-lg">
              {filtered.map((p) => (
                <button
                  key={p.id}
                  onClick={() => addToCart(p.id)}
                  disabled={p.stockPieces === 0}
                  className="flex w-full items-center justify-between border-b border-slate-100 px-4 py-2.5 text-left last:border-b-0 hover:bg-slate-50 disabled:opacity-50"
                >
                  <div>
                    <div className="font-medium text-slate-900">{p.name}</div>
                    <div className="text-xs text-slate-500">
                      {p.barcode} · {p.stockPieces} in stock
                    </div>
                  </div>
                  <div className="text-sm font-semibold text-slate-900">
                    {formatCurrency(p.sellingPrice / Math.max(1, p.piecesPerCase))}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="relative w-full sm:w-72">
          <UserIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={selectedCustomer ? selectedCustomer.name : customerQuery}
            onChange={(e) => {
              setCustomerQuery(e.target.value);
              setCustomerId("");
            }}
            placeholder="Search customer (name or phone)"
            className="h-12 w-full rounded-lg border border-slate-300 bg-white pl-10 pr-9 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-primary focus:ring-2 focus:ring-primary/30"
          />
          {selectedCustomer && (
            <button
              onClick={() => {
                setCustomerId("");
                setCustomerQuery("");
              }}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
            >
              <X className="h-4 w-4" />
            </button>
          )}
          {customerQuery && !customerId && filteredCustomers.length > 0 && (
            <div className="absolute left-0 right-0 top-full z-30 mt-1 max-h-72 overflow-auto rounded-lg border border-slate-200 bg-white shadow-lg">
              {filteredCustomers.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setCustomerId(c.id);
                    setCustomerQuery("");
                  }}
                  className="flex w-full items-center justify-between border-b border-slate-100 px-4 py-2.5 text-left last:border-b-0 hover:bg-slate-50"
                >
                  <div>
                    <div className="font-medium text-slate-900">{c.name}</div>
                    <div className="text-xs text-slate-500">{c.phone || "—"}</div>
                  </div>
                  <div className="text-xs font-semibold text-amber-600">
                    {formatCurrency(c.balance)} owed
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Stats strip */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 bg-white px-4 py-2 text-xs">
        <Stat label="Today's Sales" value={formatCurrency(todaysTotal)} />
        <Stat label="Transactions" value={String(todaysSales.length)} />
        {isAdmin && (
          <Stat
            label="Today's Profit"
            value={formatCurrency(todaysProfit)}
            tone="success"
          />
        )}
        <div className="ml-auto text-slate-500">
          Cashier: <span className="font-medium text-slate-800">{user?.fullName ?? "—"}</span>
          {openDrawer ? (
            <span className="ml-3 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-700">
              Drawer open
            </span>
          ) : (
            <span className="ml-3 rounded-full bg-rose-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-rose-700">
              Drawer closed
            </span>
          )}
        </div>
      </div>

      {/* Main grid */}
      <div className="flex flex-1 min-h-0 flex-col lg:flex-row">
        {/* Cart table */}
        <div className="flex flex-1 min-h-0 flex-col bg-white lg:border-r lg:border-slate-200">
          <div className="grid grid-cols-12 gap-2 border-b border-slate-200 bg-slate-100 px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-slate-600">
            <div className="col-span-1">#</div>
            <div className="col-span-5">Item</div>
            <div className="col-span-3 text-center">Qty</div>
            <div className="col-span-2 text-right">Price</div>
            <div className="col-span-1 text-right">Total</div>
          </div>
          <div className="flex-1 overflow-auto">
            {cart.length === 0 ? (
              <div className="flex h-full flex-col p-4">
                {recentItems.length > 0 ? (
                  <>
                    <div className="mb-3 flex items-center justify-between">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
                        Recent / Fast-moving items
                      </div>
                      <div className="text-[10px] text-slate-400">Tap to add</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-4">
                      {recentItems.map((it) => {
                        const p = products.find((pp) => pp.id === it.productId);
                        const price = p
                          ? p.sellingPrice / Math.max(1, p.piecesPerCase)
                          : 0;
                        return (
                          <button
                            key={it.productId}
                            onClick={() => addToCart(it.productId)}
                            disabled={!p || p.stockPieces === 0}
                            className="group flex flex-col items-start gap-1 rounded-lg border border-slate-200 bg-white p-2.5 text-left shadow-sm transition hover:border-primary hover:bg-primary/5 disabled:opacity-50"
                          >
                            <div className="line-clamp-2 text-xs font-semibold text-slate-900">
                              {it.name}
                            </div>
                            <div className="flex w-full items-center justify-between text-[10px] text-slate-500">
                              <span>Last: {it.qty} pcs</span>
                              <span>{formatDateTime(it.lastDate).split(",")[0]}</span>
                            </div>
                            <div className="mt-0.5 flex w-full items-center justify-between">
                              <span className="text-xs font-bold text-slate-900">
                                {formatCurrency(price)}
                              </span>
                              <span className="rounded-full bg-emerald-50 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-emerald-700 group-hover:bg-emerald-100">
                                + Add
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </>
                ) : (
                  <div className="flex h-full flex-col items-center justify-center py-20 text-center text-slate-400">
                    <Receipt className="mb-3 h-12 w-12 opacity-40" />
                    <div className="text-sm">Scan or search an item to start</div>
                  </div>
                )}
              </div>
            ) : (
              cart.map((c, idx) => (
                <div
                  key={c.productId}
                  className="grid grid-cols-12 items-center gap-2 border-b border-slate-100 px-4 py-3 hover:bg-slate-50"
                >
                  <div className="col-span-1 text-sm font-semibold text-slate-500">
                    {idx + 1}
                  </div>
                  <div className="col-span-5 min-w-0">
                    <div className="flex items-center gap-1.5 truncate text-sm font-semibold text-slate-900">
                      <span className="truncate">{c.name}</span>
                      {!c.gstApplicable && (
                        <span className="shrink-0 rounded-full bg-slate-200 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-slate-700">
                          Non-GST
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-500">
                      {c.pieces} pcs · {c.unit}
                    </div>
                  </div>
                  <div className="col-span-3 flex items-center justify-center gap-1">
                    <button
                      onClick={() => decQty(c.productId)}
                      className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <input
                      type="number"
                      min={0}
                      step="0.5"
                      value={c.unitQty}
                      onChange={(e) => setQty(c.productId, Number(e.target.value))}
                      className="h-8 w-14 rounded-md border border-slate-300 bg-white px-1 text-center text-sm font-semibold text-slate-900 outline-none focus:border-primary"
                    />
                    <button
                      onClick={() => incQty(c.productId)}
                      className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="col-span-2 text-right">
                    {isAdmin ? (
                      <input
                        type="number"
                        min={0}
                        step="0.01"
                        value={(c.pricePerPiece * c.piecesPerCase).toFixed(2)}
                        onChange={(e) =>
                          setLinePrice(c.productId, Number(e.target.value))
                        }
                        className="h-8 w-24 rounded-md border border-slate-300 bg-white px-2 text-right text-sm text-slate-900 outline-none focus:border-primary"
                      />
                    ) : (
                      <span className="text-sm text-slate-700">
                        {formatCurrency(c.pricePerPiece * c.piecesPerCase)}
                      </span>
                    )}
                  </div>
                  <div className="col-span-1 flex items-center justify-end gap-2">
                    <span className="text-sm font-bold text-slate-900">
                      {formatCurrency(c.pricePerPiece * c.pieces)}
                    </span>
                    <button
                      onClick={() => removeLine(c.productId)}
                      className="rounded p-1 text-rose-500 hover:bg-rose-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Recent sales (compact) */}
          <div className="border-t border-slate-200 bg-slate-50 px-4 py-3">
            <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              Recent sales
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {sales.slice(0, 6).map((s) => (
                <div
                  key={s.id}
                  className="min-w-[160px] rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs shadow-sm"
                >
                  <div className="text-slate-500">{formatDateTime(s.date)}</div>
                  <div className="mt-1 flex items-center justify-between">
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold uppercase text-slate-700">
                      {s.paymentMethod}
                    </span>
                    <span className="font-bold text-slate-900">
                      {formatCurrency(s.total)}
                    </span>
                  </div>
                </div>
              ))}
              {sales.length === 0 && (
                <div className="text-xs text-slate-400">No sales yet today.</div>
              )}
            </div>
          </div>
        </div>

        {/* Right summary panel — compact */}
        <div className="flex w-full flex-col bg-slate-50 lg:w-[320px]">
          <div className="flex-1 space-y-2 overflow-auto p-3">
            {/* Items count strip */}
            <div className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs shadow-sm">
              <span className="font-semibold text-slate-600">
                {itemCount} item{itemCount === 1 ? "" : "s"}
              </span>
              <span className="font-semibold text-slate-600">Qty: {totalQty}</span>
            </div>

            {/* Adjustments */}
            <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
              <div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Tax & Charges
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <Field label="GST %">
                  <div className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={gstEnabled}
                      onChange={(e) => setGstEnabled(e.target.checked)}
                      className="h-4 w-4"
                    />
                    <input
                      type="number"
                      min={0}
                      step="0.5"
                      disabled={!gstEnabled}
                      value={gstPercent}
                      onChange={(e) => setGstPercent(Number(e.target.value))}
                      className="h-8 w-full rounded-md border border-slate-300 bg-white px-2 text-xs text-slate-900 outline-none focus:border-primary disabled:bg-slate-100"
                    />
                  </div>
                </Field>
                <Field label="Card fee %">
                  <input
                    type="number"
                    min={0}
                    step="0.1"
                    value={cardPct}
                    onChange={(e) => setCardPct(Number(e.target.value))}
                    className="h-8 w-full rounded-md border border-slate-300 bg-white px-2 text-xs text-slate-900 outline-none focus:border-primary"
                  />
                </Field>
                <Field label="Bag fee">
                  <input
                    type="number"
                    min={0}
                    step="0.01"
                    value={bagFeeUnit}
                    onChange={(e) => setBagFeeUnit(Number(e.target.value))}
                    className="h-8 w-full rounded-md border border-slate-300 bg-white px-2 text-xs text-slate-900 outline-none focus:border-primary"
                  />
                </Field>
                <Field label="Bags qty">
                  <input
                    type="number"
                    min={0}
                    value={bagCount}
                    onChange={(e) =>
                      setBagCount(Math.max(0, Number(e.target.value)))
                    }
                    className="h-8 w-full rounded-md border border-slate-300 bg-white px-2 text-xs text-slate-900 outline-none focus:border-primary"
                  />
                </Field>
                <Field label="Discount" full>
                  <input
                    type="number"
                    min={0}
                    value={discount}
                    onChange={(e) =>
                      setDiscount(Math.max(0, Number(e.target.value)))
                    }
                    className="h-8 w-full rounded-md border border-slate-300 bg-white px-2 text-xs text-slate-900 outline-none focus:border-primary"
                  />
                </Field>
              </div>
            </div>

            {/* Totals */}
            <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
              {nonGstSubtotal > 0 && (
                <>
                  <SumRow
                    label="GST items"
                    value={formatCurrency(gstSubtotal)}
                  />
                  <SumRow
                    label="Non-GST items"
                    value={formatCurrency(nonGstSubtotal)}
                  />
                </>
              )}
              <SumRow label="Subtotal" value={formatCurrency(subtotal)} />
              {discountAmt > 0 && (
                <SumRow
                  label="Discount"
                  value={`-${formatCurrency(discountAmt)}`}
                />
              )}
              {gstEnabled && (
                <SumRow
                  label={`GST (${gstPercent}%)${
                    nonGstSubtotal > 0 ? " · GST items only" : ""
                  }`}
                  value={formatCurrency(gstAmount)}
                />
              )}
              {bagFee > 0 && (
                <SumRow
                  label={`Plastic bag (${bagCount})`}
                  value={formatCurrency(bagFee)}
                />
              )}
              {cardFee > 0 && (
                <SumRow
                  label={`Card charge (${cardPct}%)`}
                  value={formatCurrency(cardFee)}
                />
              )}
              {isAdmin && (
                <SumRow
                  label="Est. profit"
                  value={formatCurrency(profit)}
                  tone="success"
                />
              )}
              <div className="my-1.5 border-t border-slate-200" />
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700">
                  TOTAL
                </span>
                <span className="text-xl font-extrabold text-slate-900">
                  {formatCurrency(grandTotal)}
                </span>
              </div>
              <div className="mt-1.5 rounded-md bg-amber-50 px-2.5 py-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700">
                    Amount Due
                  </span>
                  <span className="text-base font-extrabold text-amber-700">
                    {formatCurrency(grandTotal)}
                  </span>
                </div>
              </div>
            </div>

            {/* Payment method */}
            <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
              <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Payment
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {(
                  [
                    { k: "cash", l: "Cash", i: Banknote },
                    { k: "card", l: "Card", i: CreditCard },
                    { k: "bank", l: "Bank", i: Building2 },
                    { k: "credit", l: "Credit", i: HandCoins },
                  ] as const
                ).map((m) => (
                  <button
                    key={m.k}
                    onClick={() => setPayment(m.k)}
                    className={`flex items-center justify-center gap-1.5 rounded-md border px-2 py-2 text-xs font-semibold transition ${
                      payment === m.k
                        ? "border-primary bg-primary text-primary-foreground shadow"
                        : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                    }`}
                  >
                    <m.i className="h-3.5 w-3.5" /> {m.l}
                  </button>
                ))}
              </div>
              {payment === "credit" && !customerId && (
                <div className="mt-2 rounded-md bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700">
                  Select a credit customer above to continue.
                </div>
              )}
              {payment === "credit" && selectedCustomer && (() => {
                const remaining = Math.max(
                  0,
                  selectedCustomer.creditLimit - selectedCustomer.balance
                );
                const exceeds = grandTotal > remaining;
                const notApproved = selectedCustomer.approvalStatus !== "approved";
                return (
                  <div
                    className={`mt-2 rounded-md px-3 py-2 text-xs font-medium ${
                      notApproved || exceeds
                        ? "bg-rose-50 text-rose-700"
                        : "bg-emerald-50 text-emerald-700"
                    }`}
                  >
                    {notApproved ? (
                      <>
                        Customer is <b>{selectedCustomer.approvalStatus}</b> — admin approval required before credit sale.
                      </>
                    ) : (
                      <div className="flex items-center justify-between">
                        <span>
                          Limit {formatCurrency(selectedCustomer.creditLimit)} ·
                          Balance {formatCurrency(selectedCustomer.balance)}
                        </span>
                        <span className={exceeds ? "font-bold" : ""}>
                          {exceeds
                            ? `Exceeds by ${formatCurrency(grandTotal - remaining)}`
                            : `Remaining ${formatCurrency(remaining)}`}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            {/* Tendered / Change */}
            {payment !== "credit" && (
              <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
                <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  Customer paid
                </div>
                <input
                  type="number"
                  min={0}
                  step="0.01"
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  placeholder={grandTotal.toFixed(2)}
                  className="h-10 w-full rounded-md border border-slate-300 bg-white px-2 text-right text-base font-bold text-slate-900 outline-none focus:border-primary focus:ring-2 focus:ring-primary/30"
                />
                <div className="mt-2 grid grid-cols-4 gap-1">
                  {[grandTotal, 50, 100, 500, 1000, 2000, 5000].map((v, i) =>
                    i === 0 ? (
                      <button
                        key="exact"
                        type="button"
                        onClick={() => setPaidAmount(grandTotal.toFixed(2))}
                        className="col-span-4 rounded-md border border-emerald-300 bg-emerald-50 py-1.5 text-xs font-semibold text-emerald-700 hover:bg-emerald-100"
                      >
                        Exact ({formatCurrency(grandTotal)})
                      </button>
                    ) : (
                      <button
                        key={v}
                        type="button"
                        onClick={() =>
                          setPaidAmount(String((paidNum || 0) + v))
                        }
                        className="rounded-md border border-slate-300 bg-white py-1 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                      >
                        +{v}
                      </button>
                    )
                  )}
                </div>
                <div className="mt-3 space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Total</span>
                    <span className="font-semibold text-slate-900">
                      {formatCurrency(grandTotal)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Paid</span>
                    <span className="font-semibold text-slate-900">
                      {formatCurrency(paidNum)}
                    </span>
                  </div>
                  {remainingAmt > 0 ? (
                    <div className="flex items-center justify-between rounded-lg bg-rose-50 px-3 py-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-rose-700">
                        Remaining
                      </span>
                      <span className="text-lg font-extrabold text-rose-700">
                        {formatCurrency(remainingAmt)}
                      </span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between rounded-lg bg-emerald-50 px-3 py-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                        Change
                      </span>
                      <span className="text-lg font-extrabold text-emerald-700">
                        {formatCurrency(Math.max(0, changeAmt))}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Bottom action buttons */}
          <div className="border-t border-slate-200 bg-white p-3">
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                onClick={cancelSale}
                className="h-12 border-slate-300 text-slate-700"
              >
                <X className="mr-1 h-4 w-4" /> Cancel
              </Button>
              <Button
                onClick={() => checkout(false)}
                disabled={cart.length === 0}
                className="h-12"
              >
                <Save className="mr-1 h-4 w-4" /> Save
              </Button>
              <Button
                onClick={() => checkout(true)}
                disabled={cart.length === 0}
                className="col-span-2 h-14 bg-emerald-600 text-base font-bold hover:bg-emerald-700"
              >
                <Printer className="mr-2 h-5 w-5" />
                Save &amp; Print · {formatCurrency(grandTotal)}
              </Button>
              {lastReceipt && (
                <>
                  <button
                    onClick={() => printReceipt()}
                    className="flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
                  >
                    <Printer className="h-3.5 w-3.5" /> Reprint
                  </button>
                  <button
                    onClick={downloadPdf}
                    className="flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
                  >
                    <Save className="h-3.5 w-3.5" /> Download PDF
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "success";
}) {
  return (
    <div className="rounded-md bg-slate-100 px-3 py-1.5">
      <span className="mr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
        {label}
      </span>
      <span
        className={`text-sm font-bold ${
          tone === "success" ? "text-emerald-600" : "text-slate-900"
        }`}
      >
        {value}
      </span>
    </div>
  );
}

function Field({
  label,
  children,
  full,
}: {
  label: string;
  children: React.ReactNode;
  full?: boolean;
}) {
  return (
    <label className={`block ${full ? "col-span-2" : ""}`}>
      <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wider text-slate-500">
        {label}
      </span>
      {children}
    </label>
  );
}

function SumRow({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "success";
}) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-sm text-slate-600">{label}</span>
      <span
        className={`text-sm font-semibold ${
          tone === "success" ? "text-emerald-600" : "text-slate-900"
        }`}
      >
        {value}
      </span>
    </div>
  );
}
