import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { useSettings } from "@/lib/settings";
import { Percent, ShoppingBag, CreditCard, Store, Save, ToggleLeft, ToggleRight, Building2, Landmark, FileText } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

function TextField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-foreground">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
      />
    </label>
  );
}

export default function Settings() {
  const s = useSettings();
  const [form, setForm] = useState({
    gstEnabled: s.gstEnabled,
    gstPercent: s.gstPercent,
    plasticBagFee: s.plasticBagFee,
    bagFeeTaxable: s.bagFeeTaxable,
    cardChargePercent: s.cardChargePercent,
    shopName: s.shopName,
    receiptFooter: s.receiptFooter,
    companyAddress: s.companyAddress,
    companyPhone: s.companyPhone,
    companyEmail: s.companyEmail,
    companyRegNo: s.companyRegNo,
    bankName: s.bankName,
    bankAccountName: s.bankAccountName,
    bankAccountNumber: s.bankAccountNumber,
    bankBeneficiary: s.bankBeneficiary,
    quotationValidityDays: s.quotationValidityDays,
    quotationTerms: s.quotationTerms,
  });

  const save = (): void => {
    s.set(form);
    toast.success("Settings saved");
  };

  return (
    <>
      <PageHeader
        title="Tax & POS Settings"
        description="Configure GST, plastic bag fee, bank card charge, and receipt details."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* GST */}
        <div className="pos-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Percent className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground">GST</h3>
              <p className="text-xs text-muted-foreground">Goods and Services Tax</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setForm((f) => ({ ...f, gstEnabled: !f.gstEnabled }))}
            className="mb-4 flex w-full items-center justify-between rounded-xl border border-border bg-secondary/40 px-4 py-3 text-left transition hover:bg-secondary"
          >
            <div>
              <div className="text-sm font-semibold text-foreground">GST enabled</div>
              <div className="text-xs text-muted-foreground">
                Apply GST automatically on sales
              </div>
            </div>
            {form.gstEnabled ? (
              <ToggleRight className="h-7 w-7 text-success" />
            ) : (
              <ToggleLeft className="h-7 w-7 text-muted-foreground" />
            )}
          </button>

          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">
              GST percentage (%)
            </span>
            <input
              type="number"
              min={0}
              max={100}
              step="0.1"
              disabled={!form.gstEnabled}
              value={form.gstPercent}
              onChange={(e) =>
                setForm((f) => ({ ...f, gstPercent: Number(e.target.value) }))
              }
              className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
            />
          </label>
        </div>

        {/* Plastic Bag */}
        <div className="pos-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
              <ShoppingBag className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground">Plastic Bag Fee</h3>
              <p className="text-xs text-muted-foreground">Optional add-on at checkout</p>
            </div>
          </div>
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">
              Default fee per bag
            </span>
            <input
              type="number"
              min={0}
              step="0.01"
              value={form.plasticBagFee}
              onChange={(e) =>
                setForm((f) => ({ ...f, plasticBagFee: Number(e.target.value) }))
              }
              className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
          <button
            type="button"
            onClick={() => setForm((f) => ({ ...f, bagFeeTaxable: !f.bagFeeTaxable }))}
            className="mt-3 flex w-full items-center justify-between rounded-xl border border-border bg-secondary/40 px-4 py-3 text-left transition hover:bg-secondary"
          >
            <div>
              <div className="text-sm font-semibold text-foreground">
                Bag fee is taxable
              </div>
              <div className="text-xs text-muted-foreground">
                Include the plastic bag fee in the GST taxable base
              </div>
            </div>
            {form.bagFeeTaxable ? (
              <ToggleRight className="h-7 w-7 text-success" />
            ) : (
              <ToggleLeft className="h-7 w-7 text-muted-foreground" />
            )}
          </button>
        </div>

        {/* Card Charge */}
        <div className="pos-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
              <CreditCard className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground">
                Bank Card Charge
              </h3>
              <p className="text-xs text-muted-foreground">
                Applied only when payment method is Card
              </p>
            </div>
          </div>
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">
              Card surcharge (%)
            </span>
            <input
              type="number"
              min={0}
              max={100}
              step="0.1"
              value={form.cardChargePercent}
              onChange={(e) =>
                setForm((f) => ({ ...f, cardChargePercent: Number(e.target.value) }))
              }
              className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
        </div>

        {/* Shop / receipt */}
        <div className="pos-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Store className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground">Shop & Receipt</h3>
              <p className="text-xs text-muted-foreground">Branding shown on receipts</p>
            </div>
          </div>
          <label className="mb-3 block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">Shop name</span>
            <input
              value={form.shopName}
              onChange={(e) => setForm((f) => ({ ...f, shopName: e.target.value }))}
              className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">
              Receipt footer
            </span>
            <input
              value={form.receiptFooter}
              onChange={(e) =>
                setForm((f) => ({ ...f, receiptFooter: e.target.value }))
              }
              className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
        </div>
      </div>

      {/* Company / Quotation details */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="pos-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-100 text-teal-700">
              <Building2 className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground">Company Details</h3>
              <p className="text-xs text-muted-foreground">Shown on quotations &amp; invoices</p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3">
            <TextField label="Address" value={form.companyAddress} onChange={(v) => setForm((f) => ({ ...f, companyAddress: v }))} />
            <div className="grid grid-cols-2 gap-3">
              <TextField label="Phone" value={form.companyPhone} onChange={(v) => setForm((f) => ({ ...f, companyPhone: v }))} />
              <TextField label="Email" value={form.companyEmail} onChange={(v) => setForm((f) => ({ ...f, companyEmail: v }))} />
            </div>
            <TextField label="Registration / GST No." value={form.companyRegNo} onChange={(v) => setForm((f) => ({ ...f, companyRegNo: v }))} />
          </div>
        </div>

        <div className="pos-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
              <Landmark className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground">Bank Details</h3>
              <p className="text-xs text-muted-foreground">Printed on quotation footer</p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3">
            <TextField label="Bank Name" value={form.bankName} onChange={(v) => setForm((f) => ({ ...f, bankName: v }))} />
            <TextField label="Account Name" value={form.bankAccountName} onChange={(v) => setForm((f) => ({ ...f, bankAccountName: v }))} />
            <div className="grid grid-cols-2 gap-3">
              <TextField label="Account Number" value={form.bankAccountNumber} onChange={(v) => setForm((f) => ({ ...f, bankAccountNumber: v }))} />
              <TextField label="Beneficiary" value={form.bankBeneficiary} onChange={(v) => setForm((f) => ({ ...f, bankBeneficiary: v }))} />
            </div>
          </div>
        </div>

        <div className="pos-card p-6 lg:col-span-2">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground">Quotation Defaults</h3>
              <p className="text-xs text-muted-foreground">Validity period and printed terms</p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3">
            <label className="block max-w-xs">
              <span className="mb-1.5 block text-xs font-medium text-foreground">Validity (days)</span>
              <input
                type="number"
                min={1}
                value={form.quotationValidityDays}
                onChange={(e) => setForm((f) => ({ ...f, quotationValidityDays: Number(e.target.value) }))}
                className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-foreground">Terms &amp; Conditions (one per line)</span>
              <textarea
                rows={6}
                value={form.quotationTerms}
                onChange={(e) => setForm((f) => ({ ...f, quotationTerms: e.target.value }))}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </label>
          </div>
        </div>
      </div>

      <div className="mt-6 flex justify-end">
        <Button onClick={save} size="lg" className="gap-2">
          <Save className="h-4 w-4" /> Save settings
        </Button>
      </div>
    </>
  );
}
