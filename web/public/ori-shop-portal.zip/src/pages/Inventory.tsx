import { useMemo, useState } from "react";
import PageHeader from "@/components/PageHeader";
import {
  useStore,
  landedCostPerPiece,
  landedCostTotal,
} from "@/lib/store";
import { useCurrentUser } from "@/lib/store";
import { useTaxSettings, computePrice } from "@/lib/taxSettings";
import type { Product, UnitType } from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { formatCurrency, formatNumber } from "@/lib/format";
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  ArrowDownToLine,
  ArrowUpFromLine,
} from "lucide-react";
import { toast } from "sonner";

const UNITS: UnitType[] = ["piece", "kg", "tin", "box", "case"];

interface FormState {
  name: string;
  barcode: string;
  category: string;
  supplierId: string;
  purchasePrice: number;
  sellingPrice: number;
  marginPct: number;
  unit: UnitType;
  piecesPerCase: number;
  stockPieces: number;
  reorderLevel: number;
  expiryDate: string;
  boatFee: number;
  otherCost: number;
  photo: string;
  gstApplicable: boolean;
  applyPlasticBag: boolean;
  applyCardCharge: boolean;
}

const blank: FormState = {
  name: "",
  barcode: "",
  category: "",
  supplierId: "",
  purchasePrice: 0,
  sellingPrice: 0,
  marginPct: 25,
  unit: "piece",
  piecesPerCase: 1,
  stockPieces: 0,
  reorderLevel: 10,
  expiryDate: "",
  boatFee: 0,
  otherCost: 0,
  photo: "",
  gstApplicable: true,
  applyPlasticBag: false,
  applyCardCharge: false,
};

export default function Inventory() {
  const products = useStore((s) => s.products);
  const suppliers = useStore((s) => s.suppliers);
  const addProduct = useStore((s) => s.addProduct);
  const updateProduct = useStore((s) => s.updateProduct);
  const deleteProduct = useStore((s) => s.deleteProduct);
  const adjustStock = useStore((s) => s.adjustStock);
  const user = useCurrentUser();

  const canEdit = user?.role === "admin" || user?.role === "storekeeper";

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "low" | "out">("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState<FormState>(blank);
  const [stockOpen, setStockOpen] = useState<{ id: string; name: string; mode: "in" | "out" } | null>(null);
  const [stockQty, setStockQty] = useState(0);
  const [stockReason, setStockReason] = useState("");
  const [taxOpen, setTaxOpen] = useState(false);
  const tax = useTaxSettings();

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      if (q && !p.name.toLowerCase().includes(q) && !p.barcode.toLowerCase().includes(q))
        return false;
      if (filter === "low" && !(p.stockPieces > 0 && p.stockPieces <= p.reorderLevel))
        return false;
      if (filter === "out" && p.stockPieces !== 0) return false;
      return true;
    });
  }, [products, search, filter]);

  const openNew = (): void => {
    setEditing(null);
    setForm({ ...blank, supplierId: suppliers[0]?.id ?? "" });
    setOpen(true);
  };

  const openEdit = (p: Product): void => {
    setEditing(p);
    setForm({
      name: p.name,
      barcode: p.barcode,
      category: p.category,
      supplierId: p.supplierId,
      purchasePrice: p.purchasePrice,
      sellingPrice: p.sellingPrice,
      marginPct: p.marginPct,
      unit: p.unit,
      piecesPerCase: p.piecesPerCase,
      stockPieces: p.stockPieces,
      reorderLevel: p.reorderLevel,
      expiryDate: p.expiryDate ?? "",
      boatFee: p.boatFee,
      otherCost: p.otherCost,
      photo: p.photo ?? "",
      gstApplicable: p.gstApplicable !== false,
      applyPlasticBag: false,
      applyCardCharge: false,
    });
    setOpen(true);
  };

  const submit = (): void => {
    if (!form.name.trim()) {
      toast.error("Product name is required");
      return;
    }
    const { applyPlasticBag: _ap, applyCardCharge: _ac, ...rest } = form;
    void _ap;
    void _ac;
    const payload = {
      ...rest,
      expiryDate: form.expiryDate || undefined,
      photo: form.photo || undefined,
    };
    if (editing) {
      updateProduct(editing.id, payload);
      toast.success("Product updated");
    } else {
      addProduct(payload);
      toast.success("Product added");
    }
    setOpen(false);
  };

  const onDelete = (p: Product): void => {
    if (!confirm(`Delete ${p.name}?`)) return;
    deleteProduct(p.id);
    toast.success("Product deleted");
  };

  const submitStock = (): void => {
    if (!stockOpen) return;
    const delta = stockOpen.mode === "in" ? stockQty : -stockQty;
    adjustStock(stockOpen.id, delta, stockReason || stockOpen.mode);
    toast.success(`Stock ${stockOpen.mode === "in" ? "added" : "removed"}`);
    setStockOpen(null);
    setStockQty(0);
    setStockReason("");
  };

  const breakdown = computePrice({
    purchasePrice: form.purchasePrice,
    boatFee: form.boatFee,
    otherCost: form.otherCost,
    marginPct: form.marginPct,
    applyGst: form.gstApplicable,
    gstPct: tax.gstPct,
  });
  const tempLanded = breakdown.landed;
  const tempSuggested = breakdown.finalPrice;

  return (
    <>
      <PageHeader
        title="Inventory"
        description="Manage products, stock levels, and pricing."
        actions={
          canEdit && (
            <div className="flex gap-2">
              {user?.role === "admin" && (
                <Button variant="outline" onClick={() => setTaxOpen(true)} className="gap-2">
                  Tax Settings
                </Button>
              )}
              <Button onClick={openNew} className="gap-2">
                <Plus className="h-4 w-4" /> Add Product
              </Button>
            </div>
          )
        }
      />

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or barcode..."
            className="h-10 w-full rounded-lg border border-input bg-background pl-10 pr-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </div>
        <div className="flex gap-2">
          {(["all", "low", "out"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-lg border px-3 py-2 text-xs font-medium capitalize transition ${
                filter === f
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card hover:bg-secondary"
              }`}
            >
              {f === "all" ? "All" : f === "low" ? "Low stock" : "Out of stock"}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary/60 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3 text-left">Product</th>
                <th className="px-4 py-3 text-left">Category</th>
                <th className="px-4 py-3 text-right">Stock</th>
                <th className="px-4 py-3 text-right">Landed Cost</th>
                <th className="px-4 py-3 text-right">Selling</th>
                <th className="px-4 py-3 text-right">Margin</th>
                <th className="px-4 py-3 text-right">Stock Value</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => {
                const landed = landedCostPerPiece(p);
                const profit = p.sellingPrice - landedCostTotal(p);
                const marginActual =
                  landedCostTotal(p) > 0
                    ? (profit / landedCostTotal(p)) * 100
                    : 0;
                const stockValue = landed * p.stockPieces;
                const isOut = p.stockPieces === 0;
                const isLow = !isOut && p.stockPieces <= p.reorderLevel;
                const cases = p.piecesPerCase > 1
                  ? Math.floor(p.stockPieces / p.piecesPerCase)
                  : null;
                return (
                  <tr
                    key={p.id}
                    className="border-t border-border transition hover:bg-secondary/30"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{p.name}</span>
                        {p.gstApplicable === false && (
                          <span className="rounded-full bg-slate-200 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-slate-700">
                            Non-GST
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {p.barcode} · {p.unit}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{p.category}</td>
                    <td className="px-4 py-3 text-right">
                      <div
                        className={`font-semibold ${
                          isOut ? "text-rose-600" : isLow ? "text-amber-600" : ""
                        }`}
                      >
                        {formatNumber(p.stockPieces)}
                        <span className="ml-1 text-xs font-normal text-muted-foreground">
                          pcs
                        </span>
                      </div>
                      {cases !== null && cases > 0 && (
                        <div className="text-[11px] text-muted-foreground">
                          ≈ {cases} case
                          {cases !== 1 ? "s" : ""}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">{formatCurrency(landed)}</td>
                    <td className="px-4 py-3 text-right font-medium">
                      {formatCurrency(p.sellingPrice / Math.max(1, p.piecesPerCase))}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                          marginActual >= 20
                            ? "bg-emerald-100 text-emerald-700"
                            : marginActual >= 10
                            ? "bg-amber-100 text-amber-700"
                            : "bg-rose-100 text-rose-700"
                        }`}
                      >
                        {marginActual.toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-muted-foreground">
                      {formatCurrency(stockValue)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        {canEdit && (
                          <>
                            <button
                              onClick={() => setStockOpen({ id: p.id, name: p.name, mode: "in" })}
                              title="Stock in"
                              className="rounded-md p-1.5 text-emerald-600 hover:bg-emerald-50"
                            >
                              <ArrowDownToLine className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => setStockOpen({ id: p.id, name: p.name, mode: "out" })}
                              title="Stock out"
                              className="rounded-md p-1.5 text-rose-600 hover:bg-rose-50"
                            >
                              <ArrowUpFromLine className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => openEdit(p)}
                              className="rounded-md p-1.5 hover:bg-secondary"
                            >
                              <Pencil className="h-4 w-4" />
                            </button>
                            {user?.role === "admin" && (
                              <button
                                onClick={() => onDelete(p)}
                                className="rounded-md p-1.5 text-destructive hover:bg-destructive/10"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">
                    No products match your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Product" : "Add Product"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Product name" full>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className={inputCls}
              />
            </Field>
            <Field label="Barcode / SKU">
              <input
                value={form.barcode}
                onChange={(e) => setForm({ ...form, barcode: e.target.value })}
                className={inputCls}
              />
            </Field>
            <Field label="Category">
              <input
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className={inputCls}
              />
            </Field>
            <Field label="Supplier">
              <select
                value={form.supplierId}
                onChange={(e) => setForm({ ...form, supplierId: e.target.value })}
                className={inputCls}
              >
                <option value="">— Select —</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Unit type">
              <select
                value={form.unit}
                onChange={(e) => setForm({ ...form, unit: e.target.value as UnitType })}
                className={inputCls}
              >
                {UNITS.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Pieces per case/box">
              <input
                type="number"
                min={1}
                value={form.piecesPerCase}
                onChange={(e) =>
                  setForm({ ...form, piecesPerCase: Number(e.target.value) || 1 })
                }
                className={inputCls}
              />
            </Field>
            <Field label="Purchase price (per unit)">
              <input
                type="number"
                value={form.purchasePrice}
                onChange={(e) =>
                  setForm({ ...form, purchasePrice: Number(e.target.value) })
                }
                className={inputCls}
              />
            </Field>
            <Field label="Boat fee / transport">
              <input
                type="number"
                value={form.boatFee}
                onChange={(e) => setForm({ ...form, boatFee: Number(e.target.value) })}
                className={inputCls}
              />
            </Field>
            <Field label="Other cost">
              <input
                type="number"
                value={form.otherCost}
                onChange={(e) => setForm({ ...form, otherCost: Number(e.target.value) })}
                className={inputCls}
              />
            </Field>
            <Field label="Margin %">
              <input
                type="number"
                value={form.marginPct}
                onChange={(e) => setForm({ ...form, marginPct: Number(e.target.value) })}
                className={inputCls}
              />
            </Field>
            <Field label="Selling price (per unit)">
              <input
                type="number"
                value={form.sellingPrice}
                onChange={(e) =>
                  setForm({ ...form, sellingPrice: Number(e.target.value) })
                }
                className={inputCls}
              />
            </Field>
            <Field label="Current stock (pieces)">
              <input
                type="number"
                value={form.stockPieces}
                onChange={(e) =>
                  setForm({ ...form, stockPieces: Number(e.target.value) })
                }
                className={inputCls}
              />
            </Field>
            <Field label="Reorder level (pieces)">
              <input
                type="number"
                value={form.reorderLevel}
                onChange={(e) =>
                  setForm({ ...form, reorderLevel: Number(e.target.value) })
                }
                className={inputCls}
              />
            </Field>
            <Field label="Expiry date (optional)">
              <input
                type="date"
                value={form.expiryDate ? form.expiryDate.slice(0, 10) : ""}
                onChange={(e) => setForm({ ...form, expiryDate: e.target.value })}
                className={inputCls}
              />
            </Field>
            <Field label="Photo URL (optional)" full>
              <input
                value={form.photo}
                onChange={(e) => setForm({ ...form, photo: e.target.value })}
                className={inputCls}
              />
            </Field>
          </div>

          <div className="rounded-xl border border-border bg-secondary/30 p-4">
            <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              GST status
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <div className="text-sm text-foreground">
                Is this product subject to GST?
                <div className="text-xs text-muted-foreground">
                  Cashier POS will automatically charge GST only on items marked GST applicable.
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setForm({ ...form, gstApplicable: true })}
                  className={`rounded-lg border px-4 py-2 text-xs font-bold transition ${
                    form.gstApplicable
                      ? "border-emerald-600 bg-emerald-600 text-white"
                      : "border-border bg-card text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  GST item
                </button>
                <button
                  type="button"
                  onClick={() => setForm({ ...form, gstApplicable: false })}
                  className={`rounded-lg border px-4 py-2 text-xs font-bold transition ${
                    !form.gstApplicable
                      ? "border-slate-700 bg-slate-700 text-white"
                      : "border-border bg-card text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  Non-GST item
                </button>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-dashed border-border bg-secondary/40 p-3 text-xs">
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <div>
                <div className="text-muted-foreground">Landed cost</div>
                <div className="font-semibold">{formatCurrency(breakdown.landed)}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Base ({form.marginPct}% margin)</div>
                <div className="font-semibold">{formatCurrency(breakdown.baseSelling)}</div>
              </div>
              <div>
                <div className="text-muted-foreground">GST</div>
                <div className="font-semibold">{formatCurrency(breakdown.gstAmount)}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Suggested final</div>
                <div className="font-semibold text-primary">{formatCurrency(breakdown.finalPrice)}</div>
              </div>
            </div>
            <div className="mt-2 text-muted-foreground">
              Profit per unit: <span className="font-semibold text-success">{formatCurrency(form.sellingPrice - breakdown.landed)}</span>
            </div>
            <button
              type="button"
              onClick={() => setForm({ ...form, sellingPrice: Math.round(tempSuggested * 100) / 100 })}
              className="mt-3 text-xs font-medium text-primary underline-offset-2 hover:underline"
            >
              Use suggested price →
            </button>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={submit}>{editing ? "Save changes" : "Add product"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Tax settings dialog */}
      <Dialog open={taxOpen} onOpenChange={setTaxOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tax & Charge Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="GST percentage (%)">
              <input
                type="number"
                step="0.01"
                value={tax.gstPct}
                onChange={(e) => tax.set({ gstPct: Number(e.target.value) || 0 })}
                className={inputCls}
              />
            </Field>
            <Field label="Plastic bag fee (per bag)">
              <input
                type="number"
                step="0.01"
                value={tax.plasticBagFee}
                onChange={(e) => tax.set({ plasticBagFee: Number(e.target.value) || 0 })}
                className={inputCls}
              />
            </Field>
            <Field label="Bank card charge (%)">
              <input
                type="number"
                step="0.01"
                value={tax.cardChargePct}
                onChange={(e) => tax.set({ cardChargePct: Number(e.target.value) || 0 })}
                className={inputCls}
              />
            </Field>
            <p className="text-xs text-muted-foreground">
              These rates are applied per item via the tax toggles when adding
              or editing a product, and on cashier checkout.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => { setTaxOpen(false); toast.success("Tax settings saved"); }}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stock adjust dialog */}
      <Dialog open={!!stockOpen} onOpenChange={(o) => !o && setStockOpen(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Stock {stockOpen?.mode === "in" ? "in" : "out"} — {stockOpen?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Quantity (pieces)">
              <input
                type="number"
                value={stockQty}
                onChange={(e) => setStockQty(Number(e.target.value))}
                className={inputCls}
              />
            </Field>
            <Field label="Reason / note">
              <input
                value={stockReason}
                onChange={(e) => setStockReason(e.target.value)}
                placeholder={stockOpen?.mode === "in" ? "Received, return, etc." : "Sold, transfer, etc."}
                className={inputCls}
              />
            </Field>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStockOpen(null)}>Cancel</Button>
            <Button onClick={submitStock}>Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

const inputCls =
  "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring";

interface FieldProps {
  label: string;
  children: React.ReactNode;
  full?: boolean;
}
function Field({ label, children, full }: FieldProps) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
        {label}
      </label>
      {children}
    </div>
  );
}

interface TaxToggleProps {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}
function TaxToggle({ checked, onChange, label }: TaxToggleProps) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
        checked
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-card hover:bg-secondary"
      }`}
    >
      {checked ? "✓ " : ""}
      {label}
    </button>
  );
}
